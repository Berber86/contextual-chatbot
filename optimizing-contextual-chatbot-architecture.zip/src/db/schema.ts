import {
  pgTable,
  serial,
  text,
  timestamp,
  boolean,
  jsonb,
} from "drizzle-orm/pg-core";

export interface SynapticBridgeItem {
  targetCloudSlug: string;
  targetCloudName: string;
  sharedPattern: string;
  metaphorHint: string;
  strength: number;
}

export interface CloudMemoryData {
  facts: string[];
  traits: string[];
  events: string[];
  contacts: string[];
  hypotheses: string[];
}

export const memoryClouds = pgTable("memory_clouds", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  summary: text("summary").notNull(),
  domainType: text("domain_type").notNull().default("topical"), // 'topical' | 'hobby_resource' | 'core_identity' | 'life_goal'
  memoryData: jsonb("memory_data").$type<CloudMemoryData>().notNull(),
  synapticBridges: jsonb("synaptic_bridges")
    .$type<SynapticBridgeItem[]>()
    .notNull()
    .default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export interface ArchitectureConfig {
  mode: "legacy" | "current_jev" | "synaptic_jev_v2";
  // Cloud selection strategy
  selectionFormula: "legacy_dossier" | "relative_cut_40" | "residual_plus_lateral" | "dual_choice_lens";
  absoluteThreshold: number; // e.g., 0.10
  relativeCut: number; // e.g., 0.40 in current, or residual ratio in v2
  maxPrimaryClouds: number; // e.g., 2-3
  enableLateralLens: boolean; // Second JEV choice question specifically for metaphors/analogies
  enableSerendipitySlot: boolean; // Controlled tail sampling when insightMode is on
  serendipityChance: number; // 0..1
  enableAlwaysOnCore: boolean; // Keep Traits, Hypotheses & Style outside topical clouds
  enableSleepSynapticBridges: boolean; // Attach cross-cloud bridges built during runCloudConsolidation
  archetypeStrategy: "uniform_random" | "jev_argmax" | "jev_temperature_top3";
  archetypeTemperature: number; // e.g. 0.65
  boostConnectorWhenMultiCloud: boolean;
}

export const architecturePresets = pgTable("architecture_presets", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  tagline: text("tagline").notNull(),
  description: text("description").notNull(),
  config: jsonb("config").$type<ArchitectureConfig>().notNull(),
  isBuiltIn: boolean("is_built_in").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export interface SimulationOutcome {
  legacyPickedClouds: string[];
  currentJevPickedClouds: { name: string; prob: number; reason: string }[];
  proposedPickedClouds: {
    name: string;
    prob: number;
    role: "anchor" | "semantic_neighbor" | "lateral_bridge" | "serendipity" | "core_layer";
    bridgeHint?: string;
  }[];
  cutoffMath: {
    bestProb: number;
    currentCutoff: number;
    residualMass: number;
    proposedNeighborCutoff: number;
    droppedByCurrentTrap: string[];
  };
  archetypeComparison: {
    legacyRandom: string;
    currentArgmax: string;
    proposedSampled: string;
    probabilities: Record<string, number>;
  };
  metrics: {
    costRub: { legacy: number; current: number; proposed: number };
    latencyMs: { legacy: number; current: number; proposed: number };
    associativeDepth: { legacy: number; current: number; proposed: number };
    precisionFocus: { legacy: number; current: number; proposed: number };
  };
  promptPreview: {
    currentBlock: string;
    proposedBlock: string;
  };
}

export const simulationRuns = pgTable("simulation_runs", {
  id: serial("id").primaryKey(),
  scenarioTitle: text("scenario_title").notNull(),
  userMessage: text("user_message").notNull(),
  recentContext: text("recent_context").notNull(),
  presetCode: text("preset_code").notNull(),
  outcome: jsonb("outcome").$type<SimulationOutcome>().notNull(),
  architecturalTakeaway: text("architectural_takeaway").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
