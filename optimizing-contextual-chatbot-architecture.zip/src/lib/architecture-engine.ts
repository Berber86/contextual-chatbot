import type {
  ArchitectureConfig,
  CloudMemoryData,
  SimulationOutcome,
  SynapticBridgeItem,
} from "@/db/schema";

export interface SeedCloud {
  slug: string;
  name: string;
  summary: string;
  domainType: "topical" | "hobby_resource" | "core_identity" | "life_goal";
  memoryData: CloudMemoryData;
  synapticBridges: SynapticBridgeItem[];
}

export interface DiagnosticFinding {
  id: string;
  severity: "critical" | "high" | "medium";
  fileLocation: string;
  title: string;
  symptom: string;
  legacyBehavior: string;
  currentBehavior: string;
  rootCauseMathOrLogic: string;
  boldSolutionTitle: string;
  boldSolutionSummary: string;
}

export interface BoldProposal {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  impactScore: string;
  costImpact: string;
  jevSlotsUsed: string;
  problemSolved: string;
  conceptExplanation: string;
  howItWorksSteps: string[];
  tradeoffs: string;
  referenceBlueprint: {
    file: string;
    snippet: string;
  };
}

export interface TestScenario {
  id: string;
  title: string;
  subtitle: string;
  userMessage: string;
  recentContext: string;
  primaryProbabilities: Record<string, number>; // What current single-choice JEV outputs (sums to 1.0)
  lateralProbabilities: Record<string, number>; // What a second 'lateral_bridge' choice question outputs
  archetypeProbabilities: Record<string, number>;
  noneProbability: number;
  whyCurrentFails: string;
  whatLegacyDid: string;
  whatSynapticV2Does: string;
}

export const INITIAL_CLOUDS: SeedCloud[] = [
  {
    slug: "core_identity",
    name: "Ядро личности и стиль (Global Core)",
    summary: "Сквозные черты характера, глубинные гипотезы и стиль общения — оптика всей жизни",
    domainType: "core_identity",
    memoryData: {
      facts: [
        "Не выносит формальных отписок и канцелярита, ценит точные метафоры",
      ],
      traits: [
        "Склонен к гиперфокусу и перфекционизму: если не видит осязаемого прогресса, быстро выгорает (high)",
        "Лучше всего восстанавливает ресурс через ручной труд и физическое ощущение результата (verified)",
        "Не любит прямые советы «отдохни», но мгновенно включается, когда задачу переводят в режим инженерного эксперимента (high)",
      ],
      events: [],
      contacts: [],
      hypotheses: [
        "Выгорание в ИТ возникает не от объёма кода, а от абстрактности результата и потери чувства авторства (high)",
        "Когда застревает в бесконечном рефакторинге, ему помогает принцип «чернового сруба» из столярки (medium)",
      ],
    },
    synapticBridges: [],
  },
  {
    slug: "work_sber_it",
    name: "Работа и разработка",
    summary: "Тимлидство, спринты, рефакторинг, дедлайны, выгорание от созвонов",
    domainType: "topical",
    memoryData: {
      facts: [
        "Работает бэкенд-разработчиком / техлидом, ведёт сложный сервис (verified)",
        "В команде 5 человек, часто приходится переделывать архитектуру на лету из-за смены требований (high)",
        "Разрабатывает пет-проект бота с контекстной памятью на JEV / System One (verified)",
      ],
      traits: [
        "Берёт на себя чужие задачи, когда видит, что джуны буксуют (high)",
      ],
      events: [
        "На прошлой неделе закрыл тяжёлый релиз после трёх бессонных вечеров",
      ],
      contacts: [
        "Максим — продакт-менеджер, постоянно меняет скоуп в середине спринта",
      ],
      hypotheses: [
        "Боится делегировать критический путь, потому что проще написать самому за ночь (high)",
      ],
    },
    synapticBridges: [
      {
        targetCloudSlug: "hobby_woodworking",
        targetCloudName: "Мастерская и столярка",
        sharedPattern: "Ремесло, борьба с перфекционизмом, переход от абстрактного к осязаемому",
        metaphorHint:
          "В столярке ты не шлифуешь доску нулёвкой, пока не собран каркас верстака — а в коде сейчас пытаешься полировать деталь до сборки.",
        strength: 0.92,
      },
      {
        targetCloudSlug: "dog_bobik",
        targetCloudName: "Пёс Бобик и прогулки",
        sharedPattern: "Терпение к чужому темпу обучения (джуны vs щенок), переключение головы",
        metaphorHint:
          "Как с Бобиком на дрессировке: команда закрепляется короткими подходами с поощрением, а не трёхчасовым марафоном.",
        strength: 0.78,
      },
    ],
  },
  {
    slug: "hobby_woodworking",
    name: "Мастерская и столярка",
    summary: "Работа с дубом и ясенем, ручной рубанок, японские пилы, запах стружки как антистресс",
    domainType: "hobby_resource",
    memoryData: {
      facts: [
        "По выходным строит мебель из массива ясеня в гаражной мастерской (verified)",
        "Обожает японские обушковые пилы Ryoba и соединения «ласточкин хвост» без гвоздей (high)",
        "Сделал письменный стол своими руками, гордится тем, что оставил живой край дерева (verified)",
      ],
      traits: [
        "В мастерской принимает несовершенство материала (сучки, текстуру) как красоту, а не как баг (high)",
      ],
      events: [
        "Месяц назад закончил книжный стеллаж на шипах без единого самореза",
      ],
      contacts: [],
      hypotheses: [
        "Столярка для него — антидот к цифровому миру: дерево не меняет ТЗ посередине распила (verified)",
      ],
    },
    synapticBridges: [
      {
        targetCloudSlug: "dream_japan",
        targetCloudName: "Мечта о Японии и эстетика Ваби-Саби",
        sharedPattern: "Японские инструменты, уважение к неидеальной фактуре (Ваби-Саби)",
        metaphorHint: "Японские мастера оставляют след стамески видимым как часть истории вещи.",
        strength: 0.88,
      },
    ],
  },
  {
    slug: "dog_bobik",
    name: "Пёс Бобик и прогулки",
    summary: "Корги Бобик, утренние пробежки в парке, трюки, безусловная радость",
    domainType: "hobby_resource",
    memoryData: {
      facts: [
        "Держит пса по кличке Бобик (вельш-корги), гуляет с ним в лесопарке по утрам без телефона (verified)",
        "Научил Бобика ждать у бордюра и приносить тапки только за кусочек сушёного лёгкого (high)",
      ],
      traits: [
        "Рядом с собакой умеет отпускать контроль и просто дурачиться (medium)",
      ],
      events: [
        "В субботу попали с Бобиком под ливень, промокли насквозь, но вернулись счастливые",
      ],
      contacts: [],
      hypotheses: [
        "Утренние прогулки без экрана — единственный момент дня, когда его мозг работает в дефолт-системе и рождает свежие идеи (high)",
      ],
    },
    synapticBridges: [],
  },
  {
    slug: "dream_japan",
    name: "Мечта о Японии и эстетика Ваби-Саби",
    summary: "План поездки в Киото осенью, изучение японской архитектуры, философия кинцуги",
    domainType: "life_goal",
    memoryData: {
      facts: [
        "Копит на осеннюю поездку в Киото и деревни долины Кисо (verified)",
        "Читает книги про японскую деревянную архитектуру и философию кинцуги (ремонт керамики золотом) (high)",
      ],
      traits: [
        "Вдохновляется идеей, что шрамы и переделки делают предмет ценнее (high)",
      ],
      events: [
        "Начал учить базовые фразы на японском по 15 минут перед сном",
      ],
      contacts: [],
      hypotheses: [],
    },
    synapticBridges: [],
  },
  {
    slug: "health_running",
    name: "Здоровье, сон и бег",
    summary: "Полумарафон, пульсовые зоны, режим сна, боли в шее от долгого сидения",
    domainType: "topical",
    memoryData: {
      facts: [
        "Готовится пробежать полумарафон (21.1 км) без рекордов, чисто на выносливость (high)",
        "Знает, что если начать бежать быстрее пульса 145 на первых 3 км — сдохнет на 12-м километре (verified)",
        "Когда спит меньше 6 часов подряд три дня — падает эмпатия и начинается туннельное зрение (high)",
      ],
      traits: [],
      events: [],
      contacts: [],
      hypotheses: [],
    },
    synapticBridges: [
      {
        targetCloudSlug: "work_sber_it",
        targetCloudName: "Работа и разработка",
        sharedPattern: "Управление темпом на длинной дистанции (пульсовая зона 2 vs спринт на работе)",
        metaphorHint:
          "Ты сейчас бежишь рабочий полумарафон в пятой пульсовой зоне с первого километра.",
        strength: 0.89,
      },
    ],
  },
];

export const DIAGNOSTIC_FINDINGS: DiagnosticFinding[] = [
  {
    id: "softmax-cutoff-trap",
    severity: "critical",
    fileLocation: "jev.js:274–337 (buildCloudQuestions + pickCloudsFromDistribution)",
    title: "Ловушка Softmax + порога 40% (почему почти всегда поднимается ровно 1 облако)",
    symptom:
      "Когда сообщение имеет явную тему (например, про работу или код), бот поднимает ТОЛЬКО облако «Работа», полностью отрезая все соседние и ресурсные облака.",
    legacyBehavior:
      "До jev (legacy/bot-before-jev/ui.js:2595) при памяти < 2000 символов в промпт уходило 90% ВСЕХ фактов, черт и гипотез сразу. При памяти > 2000 символов Stage 1 читал ВСЮ память целиком и сжимал досье, сохраняя кросс-доменные мостики.",
    currentBehavior:
      "Все 24 темы засунуты в ОДИН вопрос типа choice (чтобы сэкономить слоты из 32). В System One choice возвращает распределение вероятностей, сумма которых равна 1.0 (Softmax). Затем pickCloudsFromDistribution отсекает всё, что ниже ranked[0].probability * 0.40.",
    rootCauseMathOrLogic:
      "Математический коллапс: если пользователь пишет про работу и лидер «Работа» получает уверенные p₁ = 0.76, то на ВСЕ остальные 23 облака + 'none' в сумме остаётся 1 - 0.76 = 0.24! Но относительный порог равен 0.76 × 0.40 = 0.304. Ни одно второе облако физически не может набрать 0.304 из остатка 0.24! То есть при любом p₁ > 0.715 формула гарантированно убивает 2-е, 3-е и 4-е облака.",
    boldSolutionTitle: "Порог от остаточной массы (1 − p₁) + Двухконтурный выбор в JEV",
    boldSolutionSummary:
      "Считать порог для 2-го и 3-го облака не от p₁, а от остаточной вероятностной массы (1 - p₁) * 0.30, и разделить выбор в совете на 2 вопроса: прямое облако (Anchor) и боковое/ресурсное облако (Lateral Bridge).",
  },
  {
    id: "literal-question-bias",
    severity: "critical",
    fileLocation: "jev.js:295 (buildCloudQuestions instructions)",
    title: "Буквальная формулировка вопроса к JEV убивает ассоциативное мышление",
    symptom:
      "JEV никогда не выбирает «ненужные» на первый взгляд облака (хобби, собаку, мечту о Японии), когда речь идёт о выгорании, прокрастинации или тупике в задаче.",
    legacyBehavior:
      "Генеративная модель на Stage 1 и Stage 2 видела весь спектр увлечений человека и сама замечала нетривиальные параллели (Insight Mode опирался на всё «подсознание»).",
    currentBehavior:
      "Вопрос к JEV звучит утилитарно: «Какая тема памяти нужнее всего, чтобы ответить на это сообщение?». Быстрый классификатор решает задачу буквального семантического матчинга (слово «спринт» → тема «Работа»).",
    rootCauseMathOrLogic:
      "Модели класса System One (jev-1.14 / solar-decide) — отличные дискриминативные классификаторы, но они отвечают ровно на тот критерий, который задан. Если спросить «что нужно буквально», латеральные облака получат p ≈ 0.01–0.03.",
    boldSolutionTitle: "Второй слот в council.js: Линза «Латеральный мост / Аналогия»",
    boldSolutionSummary:
      "В council.js занято всего 8 вопросов из 32 (24 слота свободны!). Добавляем 9-м вопросом lateral_cloud (type: choice) с инструкцией: «Какая ДРУГАЯ сфера жизни человека (хобби, отдушина, прошлый опыт) даст лучшую метафору, контраст или эмоциональную опору, не совпадая с буквальной темой?».",
  },
  {
    id: "siloed-traits-and-missing-style",
    severity: "high",
    fileLocation: "app.js:730–785 (buildCloudContext) & ui.js:3300",
    title: "Черты характера (Traits), Гипотезы и Стиль оказались заперты в чужих папках или потеряны",
    symptom:
      "Бот стал отвечать плоско и «без психологии»: обсуждая работу, он забывает сквозные черты характера пользователя и его стиль общения.",
    legacyBehavior:
      "В legacy/bot-before-jev Traits, Hypotheses и Style (STORAGE_KEYS.style) были ГЛОБАЛЬНЫМИ: они подавались при каждом ходе независимо от темы разговора.",
    currentBehavior:
      "1) runCloudConsolidation раскладывает Traits и Hypotheses по тематическим облакам. Если черта «перфекционист, которому важен осязаемый результат» попала в облако «Столярка», то при разговоре про «Работу» бот вообще не знает об этой черте! 2) В ui.js:3300 при source === 'clouds' переменная style (STORAGE_KEYS.style) вообще перестала попадать в systemPrompt Stage 2!",
    rootCauseMathOrLogic:
      "Категориальная ошибка архитектуры памяти: Факты и События — эпизодичны (привязаны к теме/облаку), а Черты характера, Глубинные гипотезы и Стиль — ортогональны темам (это сквозная оптика личности).",
    boldSolutionTitle: "Двухслойная память: Always-On Ядро Личности + Эпизодические Облака",
    boldSolutionSummary:
      "Вывести Traits, активные Hypotheses и Style из тематической изоляции в постоянный компактный блок «Ядро личности» (~300 токенов), который прикрепляется всегда, а через JEV переключать только тематические облака фактов и событий.",
  },
  {
    id: "archetype-argmax-collapse",
    severity: "high",
    fileLocation: "jev.js:186–234 & council.js:56 (normalizeArchetype)",
    title: "Смерть архетипов Story и Connector из-за детерминированного argmax в JEV",
    symptom:
      "Раньше бот регулярно удивлял неожиданным заходом через историю (story), связь с прошлым (connector) или рефрейминг (reframe). Сейчас 85% ответов идут по сухим шаблонам answer_first, options или minimalist.",
    legacyBehavior:
      "В legacy/bot-before-jev/ui.js:2458 pickResponseArchetype() выбирал архетип через Math.random() (ровно по 12.5% на каждый из 8 архетипов). В 25% ходов бот был ОБЯЗАН провести аналогию (story) или связать с прошлым паттерном (connector)!",
    currentBehavior:
      "council.js спрашивает у JEV: «Какая форма ответа лучше всего подойдёт?», передавая только текст сообщения и 4 коротких реплики БЕЗ памяти. Не видя памяти пользователя, JEV почти всегда ставит на 1-е место answer_first или minimalist, а normalizeArchetype берёт только победителя (answer.choice).",
    rootCauseMathOrLogic:
      "Замена стохастического разнообразия на argmax классификатора без доступа к памяти убила поведенческую энтропию бота. При этом JEV УЖЕ возвращает распределение вероятностей по всем 8 архетипам (answers.archetype.probabilities), но код его выбрасывает!",
    boldSolutionTitle: "Температурное сэмплирование из Top-3 архетипов JEV + Буст Connector/Story",
    boldSolutionSummary:
      "Не брать слепой Math.random() по всем 8 (чтобы не шутить в кризис), но и не брать сухой argmax! Использовать probabilities от JEV: отсекать неуместный хвост, а из Top-3 архетипов выбирать взвешенной рулеткой с бустом для connector и story, когда поднято боковое облако.",
  },
  {
    id: "insight-mode-starvation",
    severity: "medium",
    fileLocation: "ui.js:3318–3330 (insightModePrompt + contextBlock)",
    title: "Голодание Insight Mode («Подсознанию» не из чего строить метафоры)",
    symptom:
      "Включённый по умолчанию Insight Mode требует от модели Stage 2: «Используй контекст как подсознание для метафор и смежных углов, не попугайничай прямыми фактами». Но в контексте лежат только прямые факты по текущей теме!",
    legacyBehavior:
      "В Legacy «подсознание» (contextBlock) содержало разнородные факты из разных уголков жизни, поэтому инструкция «не повторяй факты в лоб, а используй как интуицию и метафоры» работала гениально.",
    currentBehavior:
      "Инструкция Insight Mode осталась прежней (запрещает называть прямые факты и требует боковых ассоциаций), но JEV подаёт в contextBlock только 1 целевое облако по теме вопроса.",
    rootCauseMathOrLogic:
      "Противоречие между Stage 1 и Stage 2: Stage 1 (JEV) отфильтровал всё «постороннее», а Stage 2 (Insight Mode) пытается найти в отфильтрованном узком списке широкие жизненные параллели.",
    boldSolutionTitle: "Раздельная разметка в промпте: 🎯 Прямой Контекст vs 🎲 Подсознание / Боковое Облако",
    boldSolutionSummary:
      "Явно разделять в промпте Stage 2 поднятые облака на два блока: «ПРЯМОЙ КОНТЕКСТ ТЕМЫ» (для точности) и «ЛАТЕРАЛЬНЫЙ РЕЗЕРВ / БОКОВОЕ ОБЛАКО» (с инструкцией: использовать только для метафор, тона, параллелей или мотивации, если это к месту).",
  },
  {
    id: "sleep-consolidation-blindness",
    severity: "medium",
    fileLocation: "analytics.js:410–650 (runCloudConsolidation)",
    title: "Стадия «Сна» (runCloudConsolidation) раскладывает память по коробкам, но не строит мосты между ними",
    symptom:
      "Фоновая стадия разбора тратит вызов умной LLM только на таксономию (разложить по полочкам), превращая живую сеть ассоциаций в изолированные ящики картотеки.",
    legacyBehavior:
      "В Legacy карточки памяти не делились на изолированные папки, поэтому связи рождались в момент чтения всего массива.",
    currentBehavior:
      "runCloudConsolidation раз в N сообщений вызывает генеративную модель, которая видит все облака и до 40 записей разом, но просит только JSON с placements, merges и renames.",
    rootCauseMathOrLogic:
      "Самый дорогой и умный фоновый процесс («сон») используется как кладовщик, хотя именно во «сне» человеческий мозг связывает далёкие воспоминания и находит общие паттерны между работой, хобби и характером!",
    boldSolutionTitle: "Генерация «Синаптических Мостов» (Synaptic Bridges) во время стадии Сна",
    boldSolutionSummary:
      "Добавить в JSON-схему runCloudConsolidation поле bridges: пусть во время «сна» большая модель находит 2–3 неочевидные переклички между разными облаками и сохраняет их прямо в метаданные облака. На ходу они поднимаются бесплатно за 0 мс!",
  },
];

export const BOLD_PROPOSALS: BoldProposal[] = [
  {
    id: "dual-lens-council",
    number: "01",
    title: "Двухконтурный отбор в JEV: Anchor Cloud + Lateral Bridge Cloud",
    subtitle: "Используем свободные слоты council.js (сейчас занято лишь 8 из 32)",
    impactScore: "🔥 Максимальный эффект на параллели и мотивацию",
    costImpact: "0.00 ₽ доп. расходов (внутри того же запроса state)",
    jevSlotsUsed: "+2 вопроса в council.js (итого 10 из 32)",
    problemSolved:
      "Убирает однобокость выбора, когда JEV ищет только буквальное совпадение темы и игнорирует ресурсные/метафорические облака.",
    conceptExplanation:
      "В System One цена запроса зависит только от входного state, а не от количества вопросов (до 32 вопросов стоят одинаково!). Сейчас линза memory задаёт один вопрос clouds. Мы делим её на два ортогональных вопроса в том же батче: 1) clouds_primary — какая тема нужна буквально по делу; 2) clouds_lateral — какая ДРУГАЯ тема из жизни человека (увлечение, отдушина, преодолённый опыт) может послужить неожиданной аналогией, переключением или источником мотивации, плюс флажок need_lateral (noul): уместна ли сейчас вообще параллель со стороны.",
    howItWorksSteps: [
      "Вопрос №1 (clouds_primary, choice): выбирает 1–2 прямых облака по теме сообщения.",
      "Вопрос №2 (need_lateral, noul): оценивает (0..1), выиграет ли этот ход от нетривиальной параллели, метафоры или мотивационного мостика из другой сферы жизни.",
      "Вопрос №3 (clouds_lateral, choice): просит JEV выбрать самое «резонирующее по паттерну, но далёкое по теме» облако (например, при усталости в коде — столярку или бег).",
      "При сборке промпта исключаем дубли: если lateral совпал с primary, берём 2-й вариант из распределения lateral.",
    ],
    tradeoffs:
      "Никакого роста латентности или цены; при простых утилитарных вопросах need_lateral < 0.45 просто отключает боковое облако, чтобы бот не умничал без повода.",
    referenceBlueprint: {
      file: "council.js / jev.js",
      snippet: `// В buildCloudQuestions(clouds): два разных угла зрения в одном батче System One
return {
  clouds: {
    type: 'choice',
    instructions: 'Какая тема памяти ПРЯМО касается сути сообщения?',
    criteria
  },
  need_lateral: {
    type: 'noul',
    instructions: 'Выиграет ли ответ, если провести неожиданную параллель, аналогию или поддержать человека через ДРУГУЮ сферу его жизни (хобби, спорт, мечту)?',
    criteria: {
      true: 'Человек рефлексирует, застрял, выгорел или ищет взгляд со стороны — параллель оживит ответ',
      false: 'Чисто технический или быстрый вопрос — сторонние темы будут искусственными'
    }
  },
  lateral_cloud: {
    type: 'choice',
    instructions: 'Какая ДРУГАЯ тема (НЕ буквальная тема вопроса, а хобби, отдушина или контрастный опыт) лучше всего подойдёт для красивой аналогии или опоры?',
    criteria
  }
};`,
    },
  },
  {
    id: "residual-math-and-serendipity",
    number: "02",
    title: "Реформа математики pickCloudsFromDistribution + Слот Управляемой Серендипности",
    subtitle: "Исправляем Softmax-коллапс (p₁ × 0.40) и добавляем «боковое зрение»",
    impactScore: "⚡ Мгновенно возвращает 2-е и 3-е облака в 70% диалогов",
    costImpact: "0.00 ₽ (чистая математика в jev.js)",
    jevSlotsUsed: "0 новых слотов",
    problemSolved:
      "В текущей формуле при уверенном лидере p₁ = 0.78 порог 0.78 × 0.40 = 0.312 математически недостижим для остальных тем, так как сумма вероятностей в choice равна 1.0.",
    conceptExplanation:
      "Вместо сравнения соседа с лидером (pᵢ ≥ p₁ × 0.40) нужно сравнивать соседа с ОСТАТОЧНОЙ вероятностной массой (1 − p₁)! Если лидер забрал 0.78, то за оставшиеся 0.22 конкурируют остальные 23 облака. Облако, получившее 0.08 из остатка 0.22 — это очень сильный второй кандидат (36% от всего остатка!), хотя в текущей версии оно отбрасывается. Плюс добавляем «Слот Серендипности» (Serendipity Slot): если включён Insight Mode, с вероятностью 25–35% подтягиваем 1 облако из «тёплого хвоста» (0.025..0.10) через взвешенную рулетку.",
    howItWorksSteps: [
      "Лидер (Anchor #1) берётся всегда, если none < 0.5 и p₁ ≥ 0.08.",
      "Для кандидатов #2 и #3 считаем residualMass = Math.max(0.01, 1 - p₁ - p_none).",
      "Соседнее облако проходит, если его доля в остатке pᵢ / residualMass ≥ 0.28 (и pᵢ ≥ 0.04).",
      "Если включён Insight Mode и выбрано < 3 облаков, «Серендипный сэмплер» с шансом 30% вытягивает одно ресурсное облако с весами, пропорциональными √pᵢ (сглаживание температуре T=1.8).",
    ],
    tradeoffs:
      "В отличие от слепого Math.random() по всей базе, сэмплирование с температурой √pᵢ никогда не вытянет облако с нулевой вероятностью, но регулярно даёт «тёплым» темам шанс всплыть.",
    referenceBlueprint: {
      file: "jev.js (pickCloudsFromDistribution)",
      snippet: `function pickCloudsFromDistributionV2(list, probabilities, noneProbability, options = {}) {
  const ranked = list
    .map(c => ({ id: c.id, name: c.name, probability: Number(probabilities?.[c.id]) }))
    .filter(x => Number.isFinite(x.probability))
    .sort((a, b) => b.probability - a.probability);
  if (!ranked.length) return [];

  const none = Number(noneProbability) || 0;
  if (none >= 0.5 && none >= ranked[0].probability) return [];

  const leader = ranked[0];
  const picked = [ { ...leader, role: 'anchor' } ];

  // Остаточная масса вероятности после вычета лидера и 'none'
  const residualMass = Math.max(0.05, 1 - leader.probability - none);
  const neighborCut = Math.max(0.04, residualMass * 0.28);

  for (const item of ranked.slice(1)) {
    if (picked.length >= 3) break;
    if (item.probability >= neighborCut) {
      picked.push({ ...item, role: 'semantic_neighbor' });
    }
  }
  return picked;
}`,
    },
  },
  {
    id: "always-on-core-layer",
    number: "03",
    title: "Двухслойная архитектура памяти: Always-On Ядро Личности + Тематические Облака",
    subtitle: "Отделяем «Кто этот человек» (Оптику) от «Что с ним происходило» (Фактов)",
    impactScore: "🧠 Возвращает глубину понимания личности и потерянный STORAGE_KEYS.style",
    costImpact: "+250..350 входных токенов на Stage 2 (копейки)",
    jevSlotsUsed: "0 слотов",
    problemSolved:
      "Сейчас черты характера и гипотезы прячутся внутри конкретных облаков и не видны при разговоре на другие темы, а style вообще выпал из ветки source === 'clouds'.",
    conceptExplanation:
      "Память бота нельзя резать только вертикально (по темам). Её нужно резать горизонтально + вертикально: 1) Горизонтальный базовый слой (Always-On Core) — Топ-5 подтверждённых черт характера (Traits), Топ-3 активных глубинных гипотез (Hypotheses) и Стиль общения (Style). Он компактный и подаётся в Stage 2 ВСЕГДА, когда память вообще нужна. 2) Вертикальные облака (Topical Clouds) — хранят конкретные факты, хронологию, людей и пробелы по темам («Работа», «Столярка», «Япония»), которые переключает JEV.",
    howItWorksSteps: [
      "В ui.js при сборке contextBlock для ветки source === 'clouds' всегда прикреплять компактный блок === ЯДРО ЛИЧНОСТИ И СТИЛЬ ===.",
      "Включить туда getStyle(), топ-5 traits (сортировка: verified/high + свежесть) и топ-3 hypotheses.",
      "Облака оставить ответственными за эпизодику и предметный мир (Facts, Events, Social, Gaps).",
    ],
    tradeoffs:
      "Даже если JEV поднимет только 1 облако «Работа», генеративная модель Stage 2 всё равно видит характер человека, его триггеры, гипотезы и стиль общения!",
    referenceBlueprint: {
      file: "ui.js (processMessageWithTwoStages)",
      snippet: `// Всегда подаём компактное Ядро Личности поверх выбранных облаков
const coreTraits = getTraitsForPrompt(false, { limit: 5 });
const coreHypotheses = getHypothesesForPrompt(false, { limit: 3 });
const commStyle = localStorage.getItem(STORAGE_KEYS.style) || '';

const coreIdentityBlock = [
  commStyle ? \`Стиль: \${commStyle}\` : '',
  coreTraits ? \`Сквозные черты характера:\\n\${coreTraits}\` : '',
  coreHypotheses ? \`Глубинные паттерны и гипотезы:\\n\${coreHypotheses}\` : ''
].filter(Boolean).join('\\n\\n');

if (contextResult.source === 'clouds' && contextResult.cloudContext) {
  contextBlock = \`\\n=== ЯДРО ЛИЧНОСТИ ===\\n\${coreIdentityBlock}\\n\\n=== ПОДНЯТЫЕ ОБЛАКА ПАМЯТИ ===\\n\${contextResult.cloudContext}\\n\`;
}`,
    },
  },
  {
    id: "sleep-synaptic-bridges",
    number: "04",
    title: "«Синаптические Мосты» во время фоновой стадии Сна (runCloudConsolidation)",
    subtitle: "Превращаем изолированные папки-облака в ассоциативный граф без затрат в рантайме",
    impactScore: "🌌 Самое смелое решение: бот видит скрытые параллели между далёкими сферами жизни",
    costImpact: "0.00 ₽ на ходу чата (считается 1 раз в фоновом «сне»)",
    jevSlotsUsed: "0 слотов",
    problemSolved:
      "Классификатор JEV на ходу видит только короткие описания тем (describeCloud) и не способен за 300 мс придумать глубокую философскую параллель между столяркой и архитектурой микросервисов.",
    conceptExplanation:
      "У вас уже есть гениальная стадия «Сна» — runCloudConsolidation() в analytics.js! Сейчас большая LLM во сне просто раскладывает записи по папкам. Давайте дадим стадии «Сна» настоящую функцию человеческого сна (REM-фазы): находить неочевидные структурные изоморфизмы между РАЗНЫМИ облаками! Например, во сне модель видит облако «Работа» и облако «Столярка» и записывает между ними Synaptic Bridge: «Общий паттерн: в коде пользователь страдает от перфекционизма на старте, хотя в столярке умеет сначала делать черновой сруб». Когда на ходу JEV поднимает облако «Работа», этот готовый мостик + 3 опорных факта из «Столярки» подтягиваются автоматически!",
    howItWorksSteps: [
      "В cloudConsolidationPrompt (analytics.js) добавляем пункт: «Найди до 3 нетривиальных параллелей (bridges) между далёкими облаками памяти (например, Работа ↔ Хобби, Спорт ↔ Цели)».",
      "Сохраняем bridges внутри объекта облака в STORAGE_KEYS.memoryClouds.",
      "В buildCloudContext(cloudIds): когда поднято облако А, автоматически прикрепляем его активные синаптические мостики (1–2 строки с подсказкой для метафоры).",
    ],
    tradeoffs:
      "Даёт качество анализа уровня полного досье (Legacy Stage 1), но со скоростью и ценой облаков (0 мс и 0 ₽ на ходу сообщения)!",
    referenceBlueprint: {
      file: "analytics.js (cloudConsolidationPrompt)",
      snippet: `// В JSON-схему runCloudConsolidation добавляем поле "bridges":
"bridges": [
  {
    "from": "Работа",
    "to": "Мастерская и столярка",
    "pattern": "В столярке умеет не шлифовать деталь до сборки каркаса, а в коде выгорает от раннего перфекционизма"
  }
]
// При поднятии облака «Работа» в buildCloudContext автоматически добавляется:
// 🔗 Ассоциативный мост → «Мастерская и столярка»: ...`,
    },
  },
  {
    id: "temperature-archetype-sampling",
    number: "05",
    title: "Умная Стохастика Архетипов: Softmax-рулетка по вероятностям JEV вместо сухого Argmax",
    subtitle: "Возвращаем живость Legacy Math.random(), но под защитой фильтра JEV",
    impactScore: "🎭 В 3–4 раза чаще включает архетипы Story, Connector и Reframe там, где они уместны",
    costImpact: "0.00 ₽ (данные уже приходят в answers.archetype.probabilities)",
    jevSlotsUsed: "0 новых слотов",
    problemSolved:
      "В Legacy выбор архетипа был полностью слепым (Math.random() 12.5%), что давало живость, но иногда стреляло невпопад. В текущей версии взяли крайность — детерминированный answer.choice (argmax), из-за чего бот застрял в answer_first.",
    conceptExplanation:
      "JEV в ответе на вопрос choice возвращает не только ключ победителя, но и полное распределение probabilities по всем 8 архетипам! Если answer_first набрал 0.34, reframe — 0.24, connector — 0.19, а story — 0.14, текущий код в 100% случаев возьмёт answer_first. Вместо этого мы отбрасываем явно неуместные архетипы (p < 0.08), а среди оставшихся лидеров делаем взвешенный случайный выбор с температурой и бонусом ×1.5 для connector и story, если в ходу есть боковое облако!",
    howItWorksSteps: [
      "Читаем answers.archetype.probabilities из ответа System One.",
      "Отсекаем архетипы с вероятностью < 0.08 (защита от глупостей: в техническом вопросе не выпадет неуместная драма).",
      "Если поднято >1 облака или сработал латеральный мост, умножаем вес connector, story и reframe на 1.5.",
      "Выбираем архетип взвешенной рулеткой из топ-3 кандидатов.",
    ],
    tradeoffs:
      "Идеальный баланс: в отличие от Legacy, бот никогда не выберет абсурдный архетип, но перестанет быть предсказуемым роботом.",
    referenceBlueprint: {
      file: "jev.js (normalizeArchetype)",
      snippet: `function pickArchetypeFromDistribution(answer, hasLateralCloud = false) {
  const probs = answer?.probabilities || {};
  const candidates = Object.keys(RESPONSE_ARCHETYPES)
    .map(key => {
      let weight = Number(probs[key]) || 0;
      if (hasLateralCloud && ['connector', 'story', 'reframe'].includes(key)) {
        weight *= 1.55; // буст ассоциативных форм ответа при наличии бокового облака
      }
      return { key, weight };
    })
    .filter(c => c.weight >= 0.08)
    .sort((a, b) => b.weight - a.weight)
    .slice(0, 3);

  if (!candidates.length) return normalizeArchetype(answer);
  const total = candidates.reduce((acc, c) => acc + c.weight, 0);
  let roll = Math.random() * total;
  for (const c of candidates) {
    roll -= c.weight;
    if (roll <= 0) return { key: c.key, instruction: RESPONSE_ARCHETYPES[c.key] };
  }
  return { key: candidates[0].key, instruction: RESPONSE_ARCHETYPES[candidates[0].key] };
}`,
    },
  },
  {
    id: "two-zone-prompt-framing",
    number: "06",
    title: "Двухзонная подача памяти в Stage 2: 🎯 Фокус vs 🌊 Боковое зрение (Subconscious)",
    subtitle: "Учим генеративную модель не путать прямые факты и материал для метафор",
    impactScore: "✨ Естественные параллели без ощущения «бот искусственно приплёл мою собаку»",
    costImpact: "0.00 ₽",
    jevSlotsUsed: "0 слотов",
    problemSolved:
      "Главная опасность простого подмешивания рандомного облака: если положить облако «Собака Бобик» в общий список фактов без пометки, слабая или средняя модель (GLM 5.2 / Nemotron) начнёт топорно спрашивать про собаку посреди разговора про код.",
    conceptExplanation:
      "Если мы подтягиваем боковое/ресурсное облако (через Lateral Lens или Serendipity Slot), нельзя сваливать его в одну кучу с основным облаком! В промпте Stage 2 нужно создать две чётко разграниченные зоны: Зона 1 — «🎯 ПРЯМОЙ КОНТЕКСТ ПО ТЕМЕ» (использовать для точных ответов) и Зона 2 — «🌊 ФОНОВЫЙ РЕЗОНАНС / ДРУГИЕ ГРАНИ ЖИЗНИ» с явной инструкцией: «Эти факты из другой сферы жизни. НЕ пересказывай их в лоб и НЕ переводи на них тему насильно. Используй их ТОЛЬКО если из них рождается точная метафора, параллель, тонкая шутка или опора для мотивации».",
    howItWorksSteps: [
      "В buildCloudContext разделяем облака по роли: anchor/semantic_neighbor идут в основной блок.",
      "Облака с ролью lateral_bridge или serendipity оформляются в блок === 🌊 БОКОВОЕ ЗРЕНИЕ (ДЛЯ АНАЛОГИЙ И ПАРАЛЛЕЛЕЙ) ===.",
      "Добавляем 2 строки контракта: запрет на буквальный перевод темы + разрешение на метафорический мостик.",
    ],
    tradeoffs:
      "Полностью защищает от эффекта «шизофазии» при добавлении случайных или далёких облаков: если модель видит красивую параллель — она её проводит, если параллель не клеится — она спокойно игнорирует фоновый блок.",
    referenceBlueprint: {
      file: "app.js / ui.js",
      snippet: `=== 🎯 ПАМЯТЬ: ПРЯМОЙ КОНТЕКСТ ===
[Облако «Работа и разработка»]

=== 🌊 БОКОВОЕ ЗРЕНИЕ (АССОЦИАТИВНЫЙ РЕЗЕРВ) ===
[Облако «Мастерская и столярка» + Синаптический мост]
ПРАВИЛО БОКОВОГО ЗРЕНИЯ: Эта тема НЕ относится к вопросу напрямую. Категорически запрещено искусственно переводить разговор на неё в лоб. Используй её только как источник тонкой метафоры, параллели или жизненного принципа пользователя, если это усилит ответ.`,
    },
  },
];

export const TEST_SCENARIOS: TestScenario[] = [
  {
    id: "sprint-burnout",
    title: "Сценарий 1: Выгорание и перфекционизм на спринте",
    subtitle: "Проверка способности связать ИТ-выгорание с мастерской/столяркой или темпом в беге",
    userMessage:
      "Опять сижу в двенадцать ночи, переписываю один и тот же модуль третий раз. Кажется, что код всё ещё кривой, а Максим утром снова поменяет требования. Вообще руки опускаются.",
    recentContext:
      "USER: На этой неделе закрываем архитектурный спринт.\nASSISTANT: Держись, там много легаси.\nUSER: Да, пытаюсь сделать сразу идеально, чтобы потом не стыдно было.",
    primaryProbabilities: {
      work_sber_it: 0.78,
      health_running: 0.08,
      hobby_woodworking: 0.05,
      dream_japan: 0.03,
      dog_bobik: 0.02,
    },
    lateralProbabilities: {
      hobby_woodworking: 0.46,
      health_running: 0.28,
      dream_japan: 0.16,
      dog_bobik: 0.07,
      work_sber_it: 0.03,
    },
    archetypeProbabilities: {
      answer_first: 0.31,
      reframe: 0.25,
      connector: 0.21,
      story: 0.12,
      reality_check: 0.06,
      micro_plan: 0.03,
      options: 0.01,
      minimalist: 0.01,
    },
    noneProbability: 0.04,
    whyCurrentFails:
      "В текущем jev.js «Работа» получает p = 0.78. Относительный порог 0.78 × 0.40 = 0.312 отрезает и «Здоровье/Бег» (0.08), и «Столярку» (0.05). Архетип по argmax выбирается answer_first (0.31). В итоге бот даёт банальный совет про декомпозицию тасок и разговор с продактом Максимом, вообще не вспоминая ни столярку, ни черту характера про осязаемый результат.",
    whatLegacyDid:
      "В Legacy Stage 1 видел всю память разом и замечал, что пользователь — столяр, который ценит «черновой сруб» и эстетику Ваби-Саби (кинцуги). С шансом 37.5% выпадал архетип reframe / story / connector.",
    whatSynapticV2Does:
      "Поднимает: 1) Ядро личности (перфекционизм + осязаемый результат), 2) Фокус: «Работа» (0.78), 3) Сосед по остаточной массе: «Здоровье и бег» (0.08 ≥ 0.22×0.28), 4) Латеральный мост: «Мастерская и столярка» (0.46) + синаптический мост про шлифовку до сборки каркаса. Архетип сэмплируется как reframe или connector!",
  },
  {
    id: "junior-frustration",
    title: "Сценарий 2: Раздражение на медленного стажёра в команде",
    subtitle: "Проверка параллели между обучением джуна и дрессировкой корги Бобика",
    userMessage:
      "Три часа объяснял стажёру, как работает инвалидация кэша. Кивает, уходит — и приносит пулл-реквест, где всё сделано ровно наоборот. Проще самому за полчаса переписать, чем учить.",
    recentContext:
      "USER: Взяли нового джуна в команду, пытаюсь онбордить.\nASSISTANT: Как первые впечатления?",
    primaryProbabilities: {
      work_sber_it: 0.81,
      dog_bobik: 0.06,
      hobby_woodworking: 0.04,
      health_running: 0.03,
      dream_japan: 0.01,
    },
    lateralProbabilities: {
      dog_bobik: 0.54,
      hobby_woodworking: 0.24,
      health_running: 0.14,
      dream_japan: 0.05,
      work_sber_it: 0.03,
    },
    archetypeProbabilities: {
      answer_first: 0.29,
      reality_check: 0.24,
      story: 0.22,
      connector: 0.16,
      options: 0.05,
      reframe: 0.02,
      micro_plan: 0.01,
      minimalist: 0.01,
    },
    noneProbability: 0.05,
    whyCurrentFails:
      "Лидер «Работа» набирает 0.81 → порог 0.81 × 0.40 = 0.324. Все остальные темы в сумме имеют 0.19. Поднимается ТОЛЬКО «Работа». Бот даёт сухой менеджерский ответ про чек-листы код-ревью.",
    whatLegacyDid:
      "Видел факт про то, как пользователь терпеливо учил корги Бобика ждать у бордюра короткими подходами за кусочек лёгкого, и проводил тёплую ироничную параллель.",
    whatSynapticV2Does:
      "Через второй вопрос lateral_cloud (0.54) и синаптический мост поднимает «Пёс Бобик» в зону Бокового Зрения, а сэмплер архетипов выбирает story (аналогия) или reality_check.",
  },
  {
    id: "fear-of-ruining-project",
    title: "Сценарий 3: Страх испортить архитектуру своего пет-проекта переделками",
    subtitle: "Проверка связи между рефакторингом бота, японской философией Кинцуги и живым краем дерева",
    userMessage:
      "Смотрю на код своего бота после внедрения jev: половина решений мне нравится, но ощущение, что я своими переделками сломал ту магию, которая была в начале. Хочется вообще откатить всё назад.",
    recentContext:
      "USER: Перевёл маршрутизацию и облака памяти на System One (jev-1.14).\nASSISTANT: Стало быстрее?\nUSER: Быстрее и дешевле в 30 раз, но ответы стали какими-то узкими.",
    primaryProbabilities: {
      work_sber_it: 0.74,
      dream_japan: 0.09,
      hobby_woodworking: 0.08,
      health_running: 0.03,
      dog_bobik: 0.02,
    },
    lateralProbabilities: {
      dream_japan: 0.48,
      hobby_woodworking: 0.37,
      health_running: 0.08,
      dog_bobik: 0.05,
      work_sber_it: 0.02,
    },
    archetypeProbabilities: {
      answer_first: 0.27,
      connector: 0.26,
      reframe: 0.23,
      options: 0.14,
      story: 0.07,
      micro_plan: 0.02,
      reality_check: 0.01,
      minimalist: 0.0,
    },
    noneProbability: 0.04,
    whyCurrentFails:
      "Порог 0.74 × 0.40 = 0.296 снова отсекает и «Японию / Кинцуги» (0.09), и «Столярку» (0.08), хотя обе темы лежат на втором и третьем месте! Бот отвечает чисто технически.",
    whatLegacyDid:
      "Находил параллель с философией Кинцуги (швы от ремонта золотом делают чашу ценнее) и столом из ясеня с неидеальным живым краем.",
    whatSynapticV2Does:
      "Благодаря формуле остаточной массы (residual = 0.22, порог = 0.062) ОБА соседа — и «Мечта о Японии (Кинцуги)» (0.09), и «Столярка» (0.08) — проходят в контекст! Плюс включается архетип connector.",
  },
];

export const BUILTIN_PRESETS: {
  code: string;
  name: string;
  tagline: string;
  description: string;
  config: ArchitectureConfig;
}[] = [
  {
    code: "legacy_before_jev",
    name: "Legacy (bot-before-jev / aee911f)",
    tagline: "Вся память целиком / Сжатие досье + случайный архетип Math.random()",
    description:
      "Оригинальная архитектура из папки legacy/bot-before-jev: генеративная модель читает всю память пользователя разом (или 90% всех фактов/черт), архетип выбирается рулеткой 1 из 8 (12.5%). Высокая ассоциативность, но дорого (0.15–0.20 ₽) и медленно (1.5–4.0 с на Stage 1).",
    config: {
      mode: "legacy",
      selectionFormula: "legacy_dossier",
      absoluteThreshold: 0.0,
      relativeCut: 0.0,
      maxPrimaryClouds: 6,
      enableLateralLens: false,
      enableSerendipitySlot: true,
      serendipityChance: 0.9,
      enableAlwaysOnCore: true,
      enableSleepSynapticBridges: false,
      archetypeStrategy: "uniform_random",
      archetypeTemperature: 1.0,
      boostConnectorWhenMultiCloud: false,
    },
  },
  {
    code: "current_main_jev",
    name: "Текущая версия (main: jev.js + council.js)",
    tagline: "1 вопрос choice на все темы + отсев ≥ 40% от лучшей + argmax архетипа",
    description:
      "Текущая реализация в репозитории: один вызов System One (8 вопросов из 32), выбор тем одним вопросом choice с отсевом ranked[0].p * 0.40, детерминированный выбор архетипа и черты характера внутри тематических облаков. Очень быстро (0.35 с) и дёшево (0.002 ₽), но страдает от туннельного зрения.",
    config: {
      mode: "current_jev",
      selectionFormula: "relative_cut_40",
      absoluteThreshold: 0.1,
      relativeCut: 0.4,
      maxPrimaryClouds: 4,
      enableLateralLens: false,
      enableSerendipitySlot: false,
      serendipityChance: 0.0,
      enableAlwaysOnCore: false,
      enableSleepSynapticBridges: false,
      archetypeStrategy: "jev_argmax",
      archetypeTemperature: 0.0,
      boostConnectorWhenMultiCloud: false,
    },
  },
  {
    code: "synaptic_jev_v2",
    name: "Synaptic JEV 2.0 (Рекомендуемая Архитектура)",
    tagline: "Anchor + Lateral Lens + Остаточная масса + Ядро Личности + Синаптические Мосты Сна",
    description:
      "Смелая гибридная архитектура: сохраняет скорость (0.4 с) и копеечную цену (0.002 ₽) одного батча JEV, но использует 2 вопроса для памяти (Прямой фокус + Боковой мост для аналогий), считает порог от остаточной массы (1 - p₁), держит Черты/Гипотезы/Стиль в постоянном Ядре и подтягивает Синаптические Мосты, построенные во время «Сна».",
    config: {
      mode: "synaptic_jev_v2",
      selectionFormula: "dual_choice_lens",
      absoluteThreshold: 0.04,
      relativeCut: 0.28, // 28% от остаточной массы (1 - p_best - p_none)
      maxPrimaryClouds: 2,
      enableLateralLens: true,
      enableSerendipitySlot: true,
      serendipityChance: 0.35,
      enableAlwaysOnCore: true,
      enableSleepSynapticBridges: true,
      archetypeStrategy: "jev_temperature_top3",
      archetypeTemperature: 0.65,
      boostConnectorWhenMultiCloud: true,
    },
  },
];

export function runArchitecturalSimulation(
  scenario: TestScenario,
  clouds: SeedCloud[],
  config: ArchitectureConfig
): SimulationOutcome {
  const cloudBySlug = new Map(clouds.map((c) => [c.slug, c]));
  const topicalClouds = clouds.filter((c) => c.domainType !== "core_identity");

  // Sort primary probabilities
  const rankedPrimary = topicalClouds
    .map((c) => ({
      slug: c.slug,
      name: c.name,
      prob: Number(scenario.primaryProbabilities[c.slug] ?? 0.01),
    }))
    .sort((a, b) => b.prob - a.prob);

  const bestProb = rankedPrimary[0]?.prob ?? 0.5;
  const noneProb = scenario.noneProbability ?? 0.04;

  // 1. Current JEV formula (jev.js:328)
  const currentCutoff = Math.max(0.1, bestProb * 0.4);
  const currentJevPickedClouds = rankedPrimary
    .filter((item) => item.prob >= currentCutoff)
    .slice(0, 4)
    .map((item, idx) => ({
      name: item.name,
      prob: item.prob,
      reason:
        idx === 0
          ? `Лидер прямого вопроса choice (p = ${item.prob.toFixed(2)})`
          : `Прошёл порог ≥ 40% от лидера (${currentCutoff.toFixed(3)})`,
    }));

  // 2. Residual mass math
  const residualMass = Math.max(0.05, 1 - bestProb - noneProb);
  const proposedNeighborCutoff = Math.max(
    config.absoluteThreshold || 0.04,
    residualMass * (config.relativeCut || 0.28)
  );

  const droppedByCurrentTrap = rankedPrimary
    .slice(1)
    .filter((item) => item.prob < currentCutoff && item.prob >= proposedNeighborCutoff)
    .map((item) => `${item.name} (p=${item.prob.toFixed(2)}, доля в остатке ${Math.round((item.prob / residualMass) * 100)}%)`);

  // 3. Proposed selection according to active config toggles
  const proposedPickedClouds: SimulationOutcome["proposedPickedClouds"] = [];
  const pickedSlugs = new Set<string>();

  if (config.enableAlwaysOnCore) {
    const core = cloudBySlug.get("core_identity");
    if (core) {
      proposedPickedClouds.push({
        name: core.name,
        prob: 1.0,
        role: "core_layer",
      });
      pickedSlugs.add(core.slug);
    }
  }

  if (config.selectionFormula === "legacy_dossier") {
    for (const item of rankedPrimary) {
      proposedPickedClouds.push({
        name: item.name,
        prob: item.prob,
        role: "anchor",
      });
    }
  } else {
    // Anchor #1
    if (rankedPrimary[0]) {
      const anchor = rankedPrimary[0];
      const anchorCloud = cloudBySlug.get(anchor.slug);
      const firstBridge =
        config.enableSleepSynapticBridges && anchorCloud?.synapticBridges?.[0]
          ? `🔗 Синаптический мост («сон») → «${anchorCloud.synapticBridges[0].targetCloudName}»: ${anchorCloud.synapticBridges[0].metaphorHint}`
          : undefined;

      proposedPickedClouds.push({
        name: anchor.name,
        prob: anchor.prob,
        role: "anchor",
        bridgeHint: firstBridge,
      });
      pickedSlugs.add(anchor.slug);
    }

    // Semantic neighbors via residual mass (or relative_cut_40 if current mode)
    const activeNeighborCutoff =
      config.selectionFormula === "relative_cut_40" ? currentCutoff : proposedNeighborCutoff;

    for (const candidate of rankedPrimary.slice(1)) {
      if (
        proposedPickedClouds.filter((c) => c.role === "anchor" || c.role === "semantic_neighbor")
          .length >= (config.maxPrimaryClouds || 2)
      ) {
        break;
      }
      if (candidate.prob >= activeNeighborCutoff && !pickedSlugs.has(candidate.slug)) {
        proposedPickedClouds.push({
          name: candidate.name,
          prob: candidate.prob,
          role: "semantic_neighbor",
        });
        pickedSlugs.add(candidate.slug);
      }
    }

    // Second Council Question: Lateral Bridge Lens
    if (config.enableLateralLens) {
      const rankedLateral = topicalClouds
        .map((c) => ({
          slug: c.slug,
          name: c.name,
          prob: Number(scenario.lateralProbabilities[c.slug] ?? 0.05),
        }))
        .filter((item) => !pickedSlugs.has(item.slug))
        .sort((a, b) => b.prob - a.prob);

      if (rankedLateral[0] && rankedLateral[0].prob >= 0.15) {
        const lat = rankedLateral[0];
        const anchorCloud = cloudBySlug.get(rankedPrimary[0]?.slug || "");
        const matchingBridge = anchorCloud?.synapticBridges?.find(
          (b) => b.targetCloudSlug === lat.slug
        );

        proposedPickedClouds.push({
          name: lat.name,
          prob: lat.prob,
          role: "lateral_bridge",
          bridgeHint: matchingBridge
            ? matchingBridge.metaphorHint
            : "Выбрано вторым вопросом lateral_cloud в council.js для нетривиальной аналогии и опоры",
        });
        pickedSlugs.add(lat.slug);
      }
    }

    // Controlled Serendipity Slot (if enabled and still room for a lateral spark)
    if (config.enableSerendipitySlot && (config.serendipityChance ?? 0) > 0) {
      const remaining = rankedPrimary.filter((item) => !pickedSlugs.has(item.slug) && item.prob >= 0.02);
      if (remaining.length > 0 && (!config.enableLateralLens || proposedPickedClouds.length < 4)) {
        // Temperature-smoothed candidate from the warm tail
        const serendipityPick = remaining[0];
        proposedPickedClouds.push({
          name: serendipityPick.name,
          prob: serendipityPick.prob,
          role: "serendipity",
          bridgeHint: `🎲 Слот управляемой серендипности (вероятность в хвосте ${serendipityPick.prob.toFixed(2)}, сглажено T=1.8)`,
        });
        pickedSlugs.add(serendipityPick.slug);
      }
    }
  }

  // 4. Archetype comparison
  const archEntries = Object.entries(scenario.archetypeProbabilities).sort(
    (a, b) => b[1] - a[1]
  );
  const currentArgmax = archEntries[0]?.[0] ?? "answer_first";

  const hasLateral = proposedPickedClouds.some(
    (c) => c.role === "lateral_bridge" || c.role === "serendipity" || Boolean(c.bridgeHint)
  );
  const boostedArchetypes: Record<string, number> = {};
  let sumBoosted = 0;
  for (const [key, rawProb] of Object.entries(scenario.archetypeProbabilities)) {
    let w = rawProb;
    if (
      config.boostConnectorWhenMultiCloud &&
      hasLateral &&
      ["connector", "story", "reframe"].includes(key)
    ) {
      w *= 1.65;
    }
    boostedArchetypes[key] = w;
    sumBoosted += w;
  }
  for (const key of Object.keys(boostedArchetypes)) {
    boostedArchetypes[key] = Number((boostedArchetypes[key] / (sumBoosted || 1)).toFixed(3));
  }
  const boostedSorted = Object.entries(boostedArchetypes).sort((a, b) => b[1] - a[1]);
  const proposedSampled =
    config.archetypeStrategy === "jev_argmax"
      ? currentArgmax
      : config.archetypeStrategy === "uniform_random"
      ? "story / connector (равномерная рулетка 12.5%)"
      : `${boostedSorted[0][0]} (${Math.round(boostedSorted[0][1] * 100)}%) / ${boostedSorted[1][0]} (${Math.round(boostedSorted[1][1] * 100)}%) [Top-3 сэмплер]`;

  // 5. Build prompt previews (Current vs Proposed)
  const currentBlockLines: string[] = ["=== ПАМЯТЬ: ПОДНЯТЫЕ ОБЛАКА ==="];
  for (const item of currentJevPickedClouds) {
    const c = clouds.find((cl) => cl.name === item.name);
    if (c) {
      currentBlockLines.push(`=== ОБЛАКО «${c.name}» ===`);
      if (c.memoryData.facts.length) {
        currentBlockLines.push(
          "Факты:\n" + c.memoryData.facts.map((f, i) => `${i + 1}. ${f}`).join("\n")
        );
      }
      if (c.memoryData.traits.length) {
        currentBlockLines.push(
          "Черты:\n" + c.memoryData.traits.map((t, i) => `${i + 1}. ${t}`).join("\n")
        );
      }
    }
  }
  currentBlockLines.push(`\n=== ПОДХОД К ОТВЕТУ ===\nАрхетип: ${currentArgmax}`);

  const proposedBlockLines: string[] = [];
  const coreItem = proposedPickedClouds.find((c) => c.role === "core_layer");
  if (coreItem) {
    const coreCloud = cloudBySlug.get("core_identity");
    if (coreCloud) {
      proposedBlockLines.push("=== 🧠 ЯДРО ЛИЧНОСТИ И СТИЛЬ (ALWAYS-ON) ===");
      proposedBlockLines.push(
        "Сквозные черты:\n" +
          coreCloud.memoryData.traits.map((t, i) => `• ${t}`).join("\n")
      );
      proposedBlockLines.push(
        "Глубинные гипотезы:\n" +
          coreCloud.memoryData.hypotheses.map((h) => `• ${h}`).join("\n")
      );
    }
  }

  const primaryPicked = proposedPickedClouds.filter(
    (c) => c.role === "anchor" || c.role === "semantic_neighbor"
  );
  if (primaryPicked.length) {
    proposedBlockLines.push("\n=== 🎯 ПРЯМОЙ КОНТЕКСТ ТЕМЫ (ФОКУС) ===");
    for (const item of primaryPicked) {
      const c = clouds.find((cl) => cl.name === item.name);
      if (c) {
        proposedBlockLines.push(`[Облако «${c.name}» · p=${item.prob.toFixed(2)}]`);
        proposedBlockLines.push(
          c.memoryData.facts.map((f, i) => `${i + 1}. ${f}`).join("\n")
        );
        if (item.bridgeHint) {
          proposedBlockLines.push(item.bridgeHint);
        }
      }
    }
  }

  const lateralPicked = proposedPickedClouds.filter(
    (c) => c.role === "lateral_bridge" || c.role === "serendipity"
  );
  if (lateralPicked.length) {
    proposedBlockLines.push(
      "\n=== 🌊 БОКОВОЕ ЗРЕНИЕ (ДЛЯ АНАЛОГИЙ, ПАРАЛЛЕЛЕЙ И МОТИВАЦИИ) ==="
    );
    proposedBlockLines.push(
      "ПРАВИЛО: Не переводи тему на эти факты буквально в лоб! Используй их как источник точной метафоры, контраста или опоры на опыт пользователя."
    );
    for (const item of lateralPicked) {
      const c = clouds.find((cl) => cl.name === item.name);
      if (c) {
        proposedBlockLines.push(
          `[Латеральное облако «${c.name}» · роль: ${item.role === "lateral_bridge" ? "Выбор JEV Lateral Lens" : "Серендипный хвост"}]`
        );
        proposedBlockLines.push(
          c.memoryData.facts.slice(0, 2).map((f) => `• ${f}`).join("\n")
        );
        if (c.memoryData.hypotheses[0]) {
          proposedBlockLines.push(`• Инсайт: ${c.memoryData.hypotheses[0]}`);
        }
        if (item.bridgeHint) {
          proposedBlockLines.push(`💡 Мостик: ${item.bridgeHint}`);
        }
      }
    }
  }
  proposedBlockLines.push(`\n=== ПОДХОД К ОТВЕТУ ===\nАрхетип: ${proposedSampled}`);

  return {
    legacyPickedClouds: topicalClouds.map((c) => c.name),
    currentJevPickedClouds,
    proposedPickedClouds,
    cutoffMath: {
      bestProb,
      currentCutoff: Number(currentCutoff.toFixed(3)),
      residualMass: Number(residualMass.toFixed(3)),
      proposedNeighborCutoff: Number(proposedNeighborCutoff.toFixed(3)),
      droppedByCurrentTrap,
    },
    archetypeComparison: {
      legacyRandom: "Случайный 1 из 8 (12.5% на story, 12.5% на connector)",
      currentArgmax: `${currentArgmax} (100% детерминированный argmax)`,
      proposedSampled,
      probabilities: boostedArchetypes,
    },
    metrics: {
      costRub: {
        legacy: 0.18,
        current: 0.002,
        proposed: 0.0022,
      },
      latencyMs: {
        legacy: 2400,
        current: 360,
        proposed: 380,
      },
      associativeDepth: {
        legacy: 86,
        current: 28,
        proposed:
          30 +
          (config.enableAlwaysOnCore ? 20 : 0) +
          (config.enableLateralLens ? 24 : 0) +
          (config.enableSleepSynapticBridges ? 16 : 0) +
          (config.archetypeStrategy === "jev_temperature_top3" ? 8 : 0),
      },
      precisionFocus: {
        legacy: 64,
        current: 91,
        proposed: 94,
      },
    },
    promptPreview: {
      currentBlock: currentBlockLines.join("\n"),
      proposedBlock: proposedBlockLines.join("\n"),
    },
  };
}
