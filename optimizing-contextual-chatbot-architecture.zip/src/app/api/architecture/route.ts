import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import {
  architecturePresets,
  memoryClouds,
  simulationRuns,
  type ArchitectureConfig,
} from "@/db/schema";
import {
  BOLD_PROPOSALS,
  BUILTIN_PRESETS,
  DIAGNOSTIC_FINDINGS,
  INITIAL_CLOUDS,
  TEST_SCENARIOS,
  runArchitecturalSimulation,
} from "@/lib/architecture-engine";

async function ensureSeeded() {
  const existingClouds = await db.select().from(memoryClouds);
  if (existingClouds.length === 0) {
    for (const cloud of INITIAL_CLOUDS) {
      await db
        .insert(memoryClouds)
        .values({
          slug: cloud.slug,
          name: cloud.name,
          summary: cloud.summary,
          domainType: cloud.domainType,
          memoryData: cloud.memoryData,
          synapticBridges: cloud.synapticBridges,
        })
        .onConflictDoNothing();
    }
  }

  const existingPresets = await db.select().from(architecturePresets);
  if (existingPresets.length === 0) {
    for (const preset of BUILTIN_PRESETS) {
      await db
        .insert(architecturePresets)
        .values({
          code: preset.code,
          name: preset.name,
          tagline: preset.tagline,
          description: preset.description,
          config: preset.config,
          isBuiltIn: true,
        })
        .onConflictDoNothing();
    }
  }

  const existingRuns = await db.select().from(simulationRuns);
  if (existingRuns.length === 0) {
    const synapticPreset = BUILTIN_PRESETS.find((p) => p.code === "synaptic_jev_v2")!;
    for (const scenario of TEST_SCENARIOS) {
      const outcome = runArchitecturalSimulation(
        scenario,
        INITIAL_CLOUDS,
        synapticPreset.config
      );
      await db.insert(simulationRuns).values({
        scenarioTitle: scenario.title,
        userMessage: scenario.userMessage,
        recentContext: scenario.recentContext,
        presetCode: synapticPreset.code,
        outcome,
        architecturalTakeaway: scenario.whatSynapticV2Does,
      });
    }
  }
}

export async function GET() {
  try {
    await ensureSeeded();

    const [clouds, presets, runs] = await Promise.all([
      db.select().from(memoryClouds),
      db.select().from(architecturePresets),
      db.select().from(simulationRuns).orderBy(desc(simulationRuns.createdAt)).limit(20),
    ]);

    return NextResponse.json({
      clouds,
      presets,
      runs,
      diagnosticFindings: DIAGNOSTIC_FINDINGS,
      boldProposals: BOLD_PROPOSALS,
      testScenarios: TEST_SCENARIOS,
    });
  } catch (error) {
    console.error("GET /api/architecture error:", error);
    return NextResponse.json(
      {
        clouds: INITIAL_CLOUDS,
        presets: BUILTIN_PRESETS,
        runs: [],
        diagnosticFindings: DIAGNOSTIC_FINDINGS,
        boldProposals: BOLD_PROPOSALS,
        testScenarios: TEST_SCENARIOS,
        warning: error instanceof Error ? error.message : "Database fallback mode",
      },
      { status: 200 }
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureSeeded();
    const body = await request.json();

    if (body.action === "run_simulation") {
      const scenarioId: string = body.scenarioId || TEST_SCENARIOS[0].id;
      const customMessage: string = body.userMessage || "";
      const config: ArchitectureConfig =
        body.config || BUILTIN_PRESETS[2].config;
      const presetCode: string = body.presetCode || "custom_workbench";

      const baseScenario =
        TEST_SCENARIOS.find((s) => s.id === scenarioId) || TEST_SCENARIOS[0];

      const effectiveScenario = {
        ...baseScenario,
        userMessage: customMessage.trim() || baseScenario.userMessage,
        primaryProbabilities:
          body.primaryProbabilities || baseScenario.primaryProbabilities,
        lateralProbabilities:
          body.lateralProbabilities || baseScenario.lateralProbabilities,
      };

      const dbClouds = await db.select().from(memoryClouds);
      const seedClouds = dbClouds.map((c) => ({
        slug: c.slug,
        name: c.name,
        summary: c.summary,
        domainType: c.domainType as "topical" | "hobby_resource" | "core_identity" | "life_goal",
        memoryData: c.memoryData,
        synapticBridges: c.synapticBridges,
      }));

      const outcome = runArchitecturalSimulation(
        effectiveScenario,
        seedClouds.length ? seedClouds : INITIAL_CLOUDS,
        config
      );

      const takeaway = `Поднято облаков: ${outcome.proposedPickedClouds.length} (против ${outcome.currentJevPickedClouds.length} в текущем jev.js). Индекс ассоциативной глубины: ${outcome.metrics.associativeDepth}/100 при стоимости ${outcome.metrics.costRub.proposed} ₽.`;

      const [inserted] = await db
        .insert(simulationRuns)
        .values({
          scenarioTitle: body.scenarioTitle || effectiveScenario.title,
          userMessage: effectiveScenario.userMessage,
          recentContext: effectiveScenario.recentContext,
          presetCode,
          outcome,
          architecturalTakeaway: takeaway,
        })
        .returning();

      return NextResponse.json({ run: inserted, outcome });
    }

    if (body.action === "save_preset") {
      const code = `preset_${Date.now()}`;
      const [inserted] = await db
        .insert(architecturePresets)
        .values({
          code,
          name: body.name || "Кастомная архитектура JEV",
          tagline: body.tagline || "Пользовательская конфигурация отбора облаков",
          description:
            body.description ||
            "Сохранено из интерактивного стенда архитектора памяти.",
          config: body.config,
          isBuiltIn: false,
        })
        .returning();

      return NextResponse.json({ preset: inserted });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (error) {
    console.error("POST /api/architecture error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Internal error" },
      { status: 500 }
    );
  }
}
