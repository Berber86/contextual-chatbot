"use client";

import React, { useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  Brain,
  CheckCircle2,
  Cloud,
  Code2,
  Cpu,
  Database,
  Flame,
  GitCompare,
  Layers,
  Lightbulb,
  Network,
  Play,
  Plus,
  RefreshCw,
  Save,
  Shuffle,
  Sliders,
  Sparkles,
  Zap,
} from "lucide-react";
import type { ArchitectureConfig, SimulationOutcome } from "@/db/schema";
import {
  BOLD_PROPOSALS,
  BUILTIN_PRESETS,
  DIAGNOSTIC_FINDINGS,
  INITIAL_CLOUDS,
  TEST_SCENARIOS,
  runArchitecturalSimulation,
  type BoldProposal,
  type DiagnosticFinding,
  type SeedCloud,
  type TestScenario,
} from "@/lib/architecture-engine";

interface SavedRunRow {
  id: number;
  scenarioTitle: string;
  userMessage: string;
  recentContext: string;
  presetCode: string;
  outcome: SimulationOutcome;
  architecturalTakeaway: string;
  createdAt: string;
}

interface PresetRow {
  id?: number;
  code: string;
  name: string;
  tagline: string;
  description: string;
  config: ArchitectureConfig;
  isBuiltIn?: boolean;
}

export default function ArchitectureWorkbenchPage() {
  const [activeTab, setActiveTab] = useState<
    "simulator" | "diagnostics" | "proposals" | "clouds"
  >("simulator");

  const [clouds, setClouds] = useState<SeedCloud[]>(INITIAL_CLOUDS);
  const [presets, setPresets] = useState<PresetRow[]>(BUILTIN_PRESETS);
  const [savedRuns, setSavedRuns] = useState<SavedRunRow[]>([]);
  const [diagnostics, setDiagnostics] =
    useState<DiagnosticFinding[]>(DIAGNOSTIC_FINDINGS);
  const [proposals, setProposals] = useState<BoldProposal[]>(BOLD_PROPOSALS);
  const [scenarios, setScenarios] = useState<TestScenario[]>(TEST_SCENARIOS);

  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(
    TEST_SCENARIOS[0].id
  );
  const [customMessage, setCustomMessage] = useState<string>(
    TEST_SCENARIOS[0].userMessage
  );
  const [activePresetCode, setActivePresetCode] =
    useState<string>("synaptic_jev_v2");

  const [config, setConfig] = useState<ArchitectureConfig>(
    BUILTIN_PRESETS[2].config
  );

  // Interactive probability overrides for the active scenario
  const [leaderProbOverride, setLeaderProbOverride] = useState<number | null>(
    null
  );
  const [openBlueprintId, setOpenBlueprintId] = useState<string | null>(
    "dual-lens-council"
  );
  const [isSavingRun, setIsSavingRun] = useState(false);
  const [isSavingPreset, setIsSavingPreset] = useState(false);
  const [customPresetName, setCustomPresetName] = useState("");
  const [statusBanner, setStatusBanner] = useState<string | null>(null);

  useEffect(() => {
    async function fetchInitialData() {
      try {
        const res = await fetch("/api/architecture");
        if (!res.ok) return;
        const data = await res.json();
        if (Array.isArray(data.clouds) && data.clouds.length) {
          setClouds(data.clouds);
        }
        if (Array.isArray(data.presets) && data.presets.length) {
          setPresets(data.presets);
        }
        if (Array.isArray(data.runs)) {
          setSavedRuns(data.runs);
        }
        if (Array.isArray(data.diagnosticFindings)) {
          setDiagnostics(data.diagnosticFindings);
        }
        if (Array.isArray(data.boldProposals)) {
          setProposals(data.boldProposals);
        }
        if (Array.isArray(data.testScenarios)) {
          setScenarios(data.testScenarios);
        }
      } catch (err) {
        console.error("Failed to load initial workbench data:", err);
      }
    }
    fetchInitialData();
  }, []);

  const currentScenario = useMemo(() => {
    const base =
      scenarios.find((s) => s.id === selectedScenarioId) || scenarios[0];
    if (leaderProbOverride === null) return base;

    // Re-normalize primary probabilities when user drags the leader probability slider
    const entries = Object.entries(base.primaryProbabilities).sort(
      (a, b) => b[1] - a[1]
    );
    if (!entries.length) return base;
    const leaderKey = entries[0][0];
    const oldOthersSum = entries
      .slice(1)
      .reduce((acc, [, v]) => acc + v, 0);
    const remainingBudget = Math.max(
      0.02,
      1 - leaderProbOverride - base.noneProbability
    );

    const adjustedPrimary: Record<string, number> = {
      [leaderKey]: leaderProbOverride,
    };
    for (const [k, v] of entries.slice(1)) {
      adjustedPrimary[k] = Number(
        (oldOthersSum > 0
          ? (v / oldOthersSum) * remainingBudget
          : remainingBudget / (entries.length - 1)
        ).toFixed(3)
      );
    }

    return {
      ...base,
      userMessage: customMessage || base.userMessage,
      primaryProbabilities: adjustedPrimary,
    };
  }, [scenarios, selectedScenarioId, leaderProbOverride, customMessage]);

  const liveOutcome = useMemo(() => {
    return runArchitecturalSimulation(currentScenario, clouds, config);
  }, [currentScenario, clouds, config]);

  function handleSelectScenario(scenario: TestScenario) {
    setSelectedScenarioId(scenario.id);
    setCustomMessage(scenario.userMessage);
    setLeaderProbOverride(null);
  }

  function handleSelectPreset(preset: PresetRow) {
    setActivePresetCode(preset.code);
    setConfig({ ...preset.config });
  }

  async function handleSaveSimulationRun() {
    setIsSavingRun(true);
    setStatusBanner(null);
    try {
      const res = await fetch("/api/architecture", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "run_simulation",
          scenarioId: currentScenario.id,
          scenarioTitle: currentScenario.title,
          userMessage: customMessage,
          presetCode: activePresetCode,
          config,
          primaryProbabilities: currentScenario.primaryProbabilities,
          lateralProbabilities: currentScenario.lateralProbabilities,
        }),
      });
      const data = await res.json();
      if (data.run) {
        setSavedRuns((prev) => [data.run, ...prev.slice(0, 19)]);
        setStatusBanner(
          "Эксперимент успешно сохранён в журнал PostgreSQL (simulation_runs)."
        );
      }
    } catch (error) {
      console.error(error);
      setStatusBanner("Не удалось сохранить запуск.");
    } finally {
      setIsSavingRun(false);
    }
  }

  async function handleSaveCustomPreset() {
    if (!customPresetName.trim()) return;
    setIsSavingPreset(true);
    setStatusBanner(null);
    try {
      const res = await fetch("/api/architecture", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "save_preset",
          name: customPresetName.trim(),
          tagline: `Кастомный профиль (${config.enableLateralLens ? "Dual-Lens" : "Single-Lens"}, cut=${config.relativeCut})`,
          config,
        }),
      });
      const data = await res.json();
      if (data.preset) {
        setPresets((prev) => [...prev, data.preset]);
        setActivePresetCode(data.preset.code);
        setCustomPresetName("");
        setStatusBanner(
          `Пресет «${data.preset.name}» сохранён в таблицу architecture_presets.`
        );
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsSavingPreset(false);
    }
  }

  const topicalClouds = useMemo(
    () => clouds.filter((c) => c.domainType !== "core_identity"),
    [clouds]
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20">
      {/* Top Hero Header */}
      <header className="border-b border-slate-800/80 bg-gradient-to-b from-slate-900/90 to-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-medium mb-3">
                <Brain className="w-3.5 h-3.5" />
                <span>
                  Архитектурный аудит репозитория Berber86/contextual-chatbot
                </span>
                <span className="text-slate-500">·</span>
                <span className="font-mono text-indigo-200">
                  legacy/bot-before-jev (aee911f) → main (jev.js + council.js)
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
                Лаборатория Ассоциативной Памяти и System One (JEV)
              </h1>
              <p className="mt-1.5 text-sm text-slate-400 max-w-3xl">
                Почему после перехода на типизированные решения{" "}
                <code className="text-indigo-300 bg-slate-900 px-1.5 py-0.5 rounded">
                  jev-1.14 / solar-decide
                </code>{" "}
                бот перестал находить неожиданные параллели и подтягивать
                «ненужные» на первый взгляд факты — и как вернуть живость мышления
                без отказа от скорости и копеечной стоимости JEV.
              </p>
            </div>

            {/* Key Architectural Comparison Pill Box */}
            <div className="grid grid-cols-3 gap-2.5 bg-slate-900/90 border border-slate-800 rounded-xl p-3 shrink-0">
              <div className="px-3 py-2 rounded-lg bg-slate-950/70 border border-slate-800/80">
                <div className="text-[11px] uppercase tracking-wider text-amber-400 font-semibold">
                  Legacy (До JEV)
                </div>
                <div className="text-lg font-bold text-white mt-0.5">
                  86% <span className="text-xs font-normal text-slate-400">инсайт</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  ~0.18 ₽ · 2.4 сек · Вся память
                </div>
              </div>
              <div className="px-3 py-2 rounded-lg bg-rose-950/30 border border-rose-500/30">
                <div className="text-[11px] uppercase tracking-wider text-rose-400 font-semibold">
                  Сейчас (main jev.js)
                </div>
                <div className="text-lg font-bold text-rose-200 mt-0.5">
                  28% <span className="text-xs font-normal text-rose-300/80">инсайт</span>
                </div>
                <div className="text-[11px] text-rose-300/70 mt-0.5">
                  0.002 ₽ · 0.36 сек · 1 облако
                </div>
              </div>
              <div className="px-3 py-2 rounded-lg bg-emerald-950/30 border border-emerald-500/40">
                <div className="text-[11px] uppercase tracking-wider text-emerald-400 font-semibold">
                  Synaptic JEV 2.0
                </div>
                <div className="text-lg font-bold text-emerald-200 mt-0.5">
                  {liveOutcome.metrics.associativeDepth.proposed}%{" "}
                  <span className="text-xs font-normal text-emerald-300/80">
                    инсайт
                  </span>
                </div>
                <div className="text-[11px] text-emerald-300/70 mt-0.5">
                  0.0022 ₽ · 0.38 сек · Мосты
                </div>
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex flex-wrap gap-2 mt-6 border-t border-slate-800/80 pt-4">
            <button
              onClick={() => setActiveTab("simulator")}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === "simulator"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20"
                  : "bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800"
              }`}
            >
              <Sliders className="w-4 h-4" />
              <span>1. Интерактивный Симулятор (jev.js vs Synaptic 2.0)</span>
            </button>

            <button
              onClick={() => setActiveTab("diagnostics")}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === "diagnostics"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20"
                  : "bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800"
              }`}
            >
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span>2. Корни деградации (6 ловушек в коде)</span>
            </button>

            <button
              onClick={() => setActiveTab("proposals")}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === "proposals"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20"
                  : "bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800"
              }`}
            >
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>3. Смелые Архитектурные Решения (6 концептов)</span>
            </button>

            <button
              onClick={() => setActiveTab("clouds")}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === "clouds"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20"
                  : "bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800"
              }`}
            >
              <Network className="w-4 h-4 text-sky-400" />
              <span>4. Граф Облаков и «Синаптические Мосты Сна»</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {statusBanner && (
          <div className="mb-6 rounded-xl bg-emerald-950/50 border border-emerald-500/40 px-4 py-3 text-sm text-emerald-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{statusBanner}</span>
            </div>
            <button
              onClick={() => setStatusBanner(null)}
              className="text-xs text-emerald-300 hover:text-white"
            >
              Закрыть
            </button>
          </div>
        )}

        {/* ==================== TAB 1: SIMULATOR ==================== */}
        {activeTab === "simulator" && (
          <div className="space-y-6">
            {/* Scenario & Preset Selector Row */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left 7 cols: Scenario + Probability Math Visualizer */}
              <div className="lg:col-span-7 space-y-6">
                <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h2 className="text-base font-semibold text-white flex items-center gap-2">
                      <Play className="w-4 h-4 text-indigo-400" />
                      <span>Выберите жизненный сценарий диалога</span>
                    </h2>
                    <span className="text-xs text-slate-400">
                      Проверяет отбор облаков в{" "}
                      <code className="text-indigo-300">council.js</code>
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mb-4">
                    {scenarios.map((scen) => {
                      const active = scen.id === selectedScenarioId;
                      return (
                        <button
                          key={scen.id}
                          onClick={() => handleSelectScenario(scen)}
                          className={`text-left p-3 rounded-xl border transition-all ${
                            active
                              ? "bg-indigo-950/50 border-indigo-500/60 text-white"
                              : "bg-slate-950/60 border-slate-800/80 text-slate-300 hover:border-slate-700"
                          }`}
                        >
                          <div className="text-xs font-semibold text-indigo-300 mb-1">
                            {scen.title.split(":")[0]}
                          </div>
                          <div className="text-xs font-medium line-clamp-2">
                            {scen.title.split(":")[1] || scen.title}
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  <label className="block text-xs font-medium text-slate-400 mb-1.5">
                    Реплика пользователя (state.message в запросе к System One):
                  </label>
                  <textarea
                    rows={2}
                    value={customMessage}
                    onChange={(e) => setCustomMessage(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-indigo-500"
                  />

                  {/* Interactive Slider for Softmax Leader Probability */}
                  <div className="mt-4 pt-4 border-t border-slate-800/80">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-slate-300 font-medium">
                        Эксперимент с уверенностью лидера в{" "}
                        <code className="text-amber-300">
                          answers.clouds.probabilities
                        </code>{" "}
                        (p₁):
                      </span>
                      <span className="font-mono text-amber-300 font-semibold">
                        p₁ = {liveOutcome.cutoffMath.bestProb.toFixed(2)} ·
                        Остаток массы (1 − p₁ − none) ={" "}
                        {liveOutcome.cutoffMath.residualMass.toFixed(2)}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.35}
                      max={0.9}
                      step={0.01}
                      value={liveOutcome.cutoffMath.bestProb}
                      onChange={(e) =>
                        setLeaderProbOverride( parseFloat(e.target.value) )
                      }
                      className="w-full accent-indigo-500 cursor-pointer"
                    />
                    <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                      <span>0.35 (размытая тема)</span>
                      <span className="text-rose-400">
                        0.72+ (Точка математического коллапса p₁×0.40 в текущем
                        jev.js!)
                      </span>
                      <span>0.90 (узкий фокус)</span>
                    </div>
                  </div>
                </div>

                {/* Softmax Trap Visualizer */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                    <div>
                      <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                        <Activity className="w-4 h-4 text-rose-400" />
                        <span>
                          Визуализация распределения JEV:{" "}
                          <code className="text-rose-300">
                            pickCloudsFromDistribution
                          </code>{" "}
                          (сейчас vs Synaptic 2.0)
                        </span>
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        В вопросе типа <code className="text-slate-300">choice</code>{" "}
                        сумма вероятностей всех тем равна 1.0. Посмотрите, как
                        текущий порог{" "}
                        <code className="text-rose-300">
                          p₁ × 0.40 = {liveOutcome.cutoffMath.currentCutoff}
                        </code>{" "}
                        отрезает все вторые темы:
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {topicalClouds.map((cloud) => {
                      const pPrimary =
                        currentScenario.primaryProbabilities[cloud.slug] ?? 0.01;
                      const pLateral =
                        currentScenario.lateralProbabilities[cloud.slug] ?? 0.01;
                      const passesCurrent =
                        pPrimary >= liveOutcome.cutoffMath.currentCutoff;
                      const pickedInProposed =
                        liveOutcome.proposedPickedClouds.find(
                          (c) => c.name === cloud.name
                        );

                      return (
                        <div
                          key={cloud.slug}
                          className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/90"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2 text-xs mb-1.5">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-white">
                                {cloud.name}
                              </span>
                              <span className="text-[11px] px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                                p_primary = {pPrimary.toFixed(2)}
                              </span>
                              {config.enableLateralLens && (
                                <span className="text-[11px] px-2 py-0.5 rounded bg-indigo-950/60 text-indigo-300 border border-indigo-500/30">
                                  p_lateral = {pLateral.toFixed(2)}
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-2">
                              <span
                                className={`text-[11px] px-2 py-0.5 rounded font-medium ${
                                  passesCurrent
                                    ? "bg-rose-500/20 text-rose-200 border border-rose-500/40"
                                    : "bg-slate-900 text-slate-500 line-through"
                                }`}
                              >
                                {passesCurrent
                                  ? "В main: ВЗЯТО"
                                  : `В main: отсечено (< ${liveOutcome.cutoffMath.currentCutoff})`}
                              </span>

                              {pickedInProposed ? (
                                <span className="text-[11px] px-2.5 py-0.5 rounded font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                                  Synaptic 2.0:{" "}
                                  {pickedInProposed.role === "anchor"
                                    ? "🎯 Фокус"
                                    : pickedInProposed.role ===
                                      "semantic_neighbor"
                                    ? "🧩 Сосед по остатку"
                                    : pickedInProposed.role === "lateral_bridge"
                                    ? "🌉 Латеральный мост"
                                    : "🎲 Серендипность"}
                                </span>
                              ) : (
                                <span className="text-[11px] px-2 py-0.5 rounded bg-slate-900 text-slate-500">
                                  Пропущено
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Probability Bar */}
                          <div className="relative h-2.5 w-full bg-slate-900 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-indigo-500 to-sky-400 rounded-full transition-all duration-300"
                              style={{
                                width: `${Math.min(100, pPrimary * 100)}%`,
                              }}
                            />
                            {/* Current Cutoff Marker */}
                            <div
                              className="absolute top-0 bottom-0 w-0.5 bg-rose-500"
                              style={{
                                left: `${Math.min(
                                  100,
                                  liveOutcome.cutoffMath.currentCutoff * 100
                                )}%`,
                              }}
                              title={`Текущий порог jev.js: ${liveOutcome.cutoffMath.currentCutoff}`}
                            />
                            {/* Proposed Residual Cutoff Marker */}
                            <div
                              className="absolute top-0 bottom-0 w-0.5 bg-emerald-400"
                              style={{
                                left: `${Math.min(
                                  100,
                                  liveOutcome.cutoffMath.proposedNeighborCutoff *
                                    100
                                )}%`,
                              }}
                              title={`Порог остаточной массы: ${liveOutcome.cutoffMath.proposedNeighborCutoff}`}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                    <div className="flex items-center gap-4">
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
                        Порог в <code className="text-rose-300">main</code> (p₁ ×
                        0.40 = {liveOutcome.cutoffMath.currentCutoff})
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" />
                        Порог остаточной массы (
                        {liveOutcome.cutoffMath.proposedNeighborCutoff})
                      </span>
                    </div>
                    {liveOutcome.cutoffMath.droppedByCurrentTrap.length > 0 && (
                      <span className="text-amber-300 font-medium">
                        Потеряно из-за Softmax-ловушки:{" "}
                        {liveOutcome.cutoffMath.droppedByCurrentTrap.join(", ")}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Right 5 cols: Architectural Controls (Toggles for Bold Proposals) */}
              <div className="lg:col-span-5 space-y-6">
                <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h2 className="text-base font-semibold text-white flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-emerald-400" />
                      <span>Пульт Архитектора Памяти (Рычаги JEV)</span>
                    </h2>
                  </div>

                  {/* Preset Quick Switcher */}
                  <div className="grid grid-cols-1 gap-2 mb-4">
                    {presets.map((preset) => {
                      const active = preset.code === activePresetCode;
                      return (
                        <button
                          key={preset.code}
                          onClick={() => handleSelectPreset(preset)}
                          className={`text-left p-2.5 rounded-xl border transition-all flex items-center justify-between ${
                            active
                              ? "bg-emerald-950/40 border-emerald-500/60 text-white"
                              : "bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700"
                          }`}
                        >
                          <div>
                            <div className="text-xs font-semibold">
                              {preset.name}
                            </div>
                            <div className="text-[11px] text-slate-400">
                              {preset.tagline}
                            </div>
                          </div>
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full font-mono ${
                              active
                                ? "bg-emerald-500/20 text-emerald-300"
                                : "bg-slate-900 text-slate-500"
                            }`}
                          >
                            {active ? "АКТИВЕН" : "Выбрать"}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Individual Bold Solution Toggles */}
                  <div className="space-y-2.5 border-t border-slate-800 pt-4">
                    <label className="flex items-start gap-3 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90 cursor-pointer hover:border-indigo-500/40">
                      <input
                        type="checkbox"
                        checked={config.enableLateralLens}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            enableLateralLens: e.target.checked,
                          })
                        }
                        className="mt-1 accent-indigo-500"
                      />
                      <div className="text-xs">
                        <div className="font-semibold text-white">
                          1. Второй вопрос в council.js:{" "}
                          <code className="text-indigo-300">lateral_cloud</code>{" "}
                          (Боковой мост)
                        </div>
                        <div className="text-slate-400 mt-0.5">
                          Отдельный слот System One специально ищет ДРУГУЮ сферу
                          жизни для аналогии и мотивации (0 ₽ доп. цены).
                        </div>
                      </div>
                    </label>

                    <label className="flex items-start gap-3 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90 cursor-pointer hover:border-indigo-500/40">
                      <input
                        type="checkbox"
                        checked={
                          config.selectionFormula !== "relative_cut_40"
                        }
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            selectionFormula: e.target.checked
                              ? "dual_choice_lens"
                              : "relative_cut_40",
                          })
                        }
                        className="mt-1 accent-indigo-500"
                      />
                      <div className="text-xs">
                        <div className="font-semibold text-white">
                          2. Порог от остаточной массы{" "}
                          <code className="text-emerald-300">
                            (1 − p₁) × 0.28
                          </code>{" "}
                          вместо{" "}
                          <code className="text-rose-300">p₁ × 0.40</code>
                        </div>
                        <div className="text-slate-400 mt-0.5">
                          Спасает 2-е и 3-е облака от математического вымирания
                          при уверенном лидере.
                        </div>
                      </div>
                    </label>

                    <label className="flex items-start gap-3 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90 cursor-pointer hover:border-indigo-500/40">
                      <input
                        type="checkbox"
                        checked={config.enableAlwaysOnCore}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            enableAlwaysOnCore: e.target.checked,
                          })
                        }
                        className="mt-1 accent-indigo-500"
                      />
                      <div className="text-xs">
                        <div className="font-semibold text-white">
                          3. Always-On «Ядро Личности» (Traits + Hypotheses +
                          Style)
                        </div>
                        <div className="text-slate-400 mt-0.5">
                          Выносит сквозные черты характера и потерянный{" "}
                          <code>STORAGE_KEYS.style</code> из тематических папок в
                          постоянный базовый слой.
                        </div>
                      </div>
                    </label>

                    <label className="flex items-start gap-3 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90 cursor-pointer hover:border-indigo-500/40">
                      <input
                        type="checkbox"
                        checked={config.enableSleepSynapticBridges}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            enableSleepSynapticBridges: e.target.checked,
                          })
                        }
                        className="mt-1 accent-indigo-500"
                      />
                      <div className="text-xs">
                        <div className="font-semibold text-white">
                          4. «Синаптические Мосты Сна» (из{" "}
                          <code className="text-sky-300">
                            runCloudConsolidation
                          </code>
                          )
                        </div>
                        <div className="text-slate-400 mt-0.5">
                          Фоновая стадия разбора заранее находит параллели между
                          далёкими темами (Работа ↔ Столярка).
                        </div>
                      </div>
                    </label>

                    <label className="flex items-start gap-3 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90 cursor-pointer hover:border-indigo-500/40">
                      <input
                        type="checkbox"
                        checked={
                          config.archetypeStrategy === "jev_temperature_top3"
                        }
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            archetypeStrategy: e.target.checked
                              ? "jev_temperature_top3"
                              : "jev_argmax",
                          })
                        }
                        className="mt-1 accent-indigo-500"
                      />
                      <div className="text-xs">
                        <div className="font-semibold text-white">
                          5. Температурный сэмплер архетипов (Top-3 + буст{" "}
                          <code className="text-amber-300">
                            connector/story
                          </code>
                          )
                        </div>
                        <div className="text-slate-400 mt-0.5">
                          Заменяет сухой argmax (<code>answer_first</code>) на
                          взвешенную рулетку по вероятностям JEV.
                        </div>
                      </div>
                    </label>

                    <label className="flex items-start gap-3 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90 cursor-pointer hover:border-indigo-500/40">
                      <input
                        type="checkbox"
                        checked={config.enableSerendipitySlot}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            enableSerendipitySlot: e.target.checked,
                          })
                        }
                        className="mt-1 accent-indigo-500"
                      />
                      <div className="text-xs">
                        <div className="font-semibold text-white">
                          6. Слот Управляемой Серендипности (Тёплый хвост √pᵢ)
                        </div>
                        <div className="text-slate-400 mt-0.5">
                          Мягкая стохастическая инъекция облака из тёплого хвоста
                          при активном Insight Mode.
                        </div>
                      </div>
                    </label>
                  </div>

                  {/* Save Buttons */}
                  <div className="mt-4 pt-4 border-t border-slate-800 space-y-2.5">
                    <button
                      onClick={handleSaveSimulationRun}
                      disabled={isSavingRun}
                      className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                    >
                      <Save className="w-4 h-4" />
                      <span>
                        {isSavingRun
                          ? "Сохраняю в PostgreSQL..."
                          : "Зафиксировать результат симуляции в БД"}
                      </span>
                    </button>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Название вашего пресета архитектуры..."
                        value={customPresetName}
                        onChange={(e) => setCustomPresetName(e.target.value)}
                        className="flex-1 rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-slate-200"
                      />
                      <button
                        onClick={handleSaveCustomPreset}
                        disabled={isSavingPreset || !customPresetName.trim()}
                        className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-medium text-slate-200 shrink-0"
                      >
                        Сохранить пресет
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Side-by-Side Prompt Context Comparison */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Current Main Prompt */}
              <div className="bg-slate-900/80 border border-rose-500/30 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider font-semibold text-rose-400">
                      Что уходит в Stage 2 сейчас (main / ui.js:3300)
                    </span>
                    <h3 className="text-sm font-bold text-white mt-0.5">
                      Туннельный контекст: 1 облако + argmax архетип
                    </h3>
                  </div>
                  <span className="text-xs px-2.5 py-1 rounded-full bg-rose-950/60 border border-rose-500/40 text-rose-200 font-mono">
                    {liveOutcome.currentJevPickedClouds.length} тема
                  </span>
                </div>

                <p className="text-xs text-slate-400 mb-3">
                  {currentScenario.whyCurrentFails}
                </p>

                <pre className="text-xs font-mono bg-slate-950 border border-slate-800 rounded-xl p-4 text-slate-300 overflow-x-auto whitespace-pre-wrap leading-relaxed max-h-80 overflow-y-auto">
                  {liveOutcome.promptPreview.currentBlock}
                </pre>
              </div>

              {/* Proposed Synaptic JEV 2.0 Prompt */}
              <div className="bg-slate-900/80 border border-emerald-500/40 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider font-semibold text-emerald-400">
                      Что уходит в Stage 2 в Synaptic JEV 2.0
                    </span>
                    <h3 className="text-sm font-bold text-white mt-0.5">
                      Ядро Личности + 🎯 Фокус + 🌊 Боковое зрение + Синаптический мост
                    </h3>
                  </div>
                  <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 font-mono">
                    {liveOutcome.proposedPickedClouds.length} слоёв
                  </span>
                </div>

                <p className="text-xs text-slate-400 mb-3">
                  {currentScenario.whatSynapticV2Does}
                </p>

                <pre className="text-xs font-mono bg-slate-950 border border-emerald-900/50 rounded-xl p-4 text-emerald-100 overflow-x-auto whitespace-pre-wrap leading-relaxed max-h-80 overflow-y-auto">
                  {liveOutcome.promptPreview.proposedBlock}
                </pre>
              </div>
            </div>

            {/* Saved Simulation Runs from PostgreSQL */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Database className="w-4 h-4 text-indigo-400" />
                  <span>
                    Журнал симуляций в PostgreSQL (таблица{" "}
                    <code className="text-indigo-300">simulation_runs</code>)
                  </span>
                </h3>
                <span className="text-xs text-slate-400">
                  Записей: {savedRuns.length}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {savedRuns.slice(0, 6).map((run) => (
                  <div
                    key={run.id}
                    className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/90 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-xs font-semibold text-indigo-300 truncate">
                          {run.scenarioTitle}
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-400">
                          {run.presetCode}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 line-clamp-2 italic mb-2">
                        «{run.userMessage}»
                      </p>
                    </div>
                    <div className="text-[11px] text-emerald-300/90 border-t border-slate-800/80 pt-2">
                      {run.architecturalTakeaway}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ==================== TAB 2: DIAGNOSTICS ==================== */}
        {activeTab === "diagnostics" && (
          <div className="space-y-5">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
              <h2 className="text-lg font-bold text-white">
                Построчное сравнение{" "}
                <code className="text-amber-300">legacy/bot-before-jev</code> и{" "}
                <code className="text-indigo-300">main</code>: 6 причин потери
                ассоциативности
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                Деградация возникла не потому, что модель{" "}
                <code>jev-1.14 / solar-decide</code> «глупая», а потому, что при
                переходе от генеративного сжатия к типизированным вопросам{" "}
                <code>System One</code> в коде сошлись 6 неочевидных математических и
                архитектурных ограничений.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {diagnostics.map((item, index) => (
                <div
                  key={item.id}
                  className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2.5">
                      <span className="w-7 h-7 rounded-lg bg-rose-500/20 border border-rose-500/40 text-rose-300 font-bold text-xs flex items-center justify-center">
                        #{index + 1}
                      </span>
                      <h3 className="text-base font-bold text-white">
                        {item.title}
                      </h3>
                    </div>
                    <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-slate-950 border border-slate-800 text-indigo-300">
                      {item.fileLocation}
                    </span>
                  </div>

                  <p className="text-sm text-rose-200/90 bg-rose-950/20 border border-rose-500/20 rounded-xl p-3 mb-4">
                    <strong className="text-rose-300">Симптом:</strong>{" "}
                    {item.symptom}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                    <div className="p-3.5 rounded-xl bg-slate-950/70 border border-amber-500/20">
                      <div className="font-semibold text-amber-300 mb-1">
                        Как было в Legacy (bot-before-jev):
                      </div>
                      <p className="text-slate-300 leading-relaxed">
                        {item.legacyBehavior}
                      </p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950/70 border border-rose-500/20">
                      <div className="font-semibold text-rose-300 mb-1">
                        Как сделано сейчас (main):
                      </div>
                      <p className="text-slate-300 leading-relaxed">
                        {item.currentBehavior}
                      </p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950/70 border border-indigo-500/30">
                      <div className="font-semibold text-indigo-300 mb-1">
                        Математический / Архитектурный корень:
                      </div>
                      <p className="text-slate-300 leading-relaxed">
                        {item.rootCauseMathOrLogic}
                      </p>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <div className="text-emerald-300">
                      <strong>Архитектурное лекарство:</strong>{" "}
                      {item.boldSolutionTitle} — {item.boldSolutionSummary}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==================== TAB 3: BOLD PROPOSALS ==================== */}
        {activeTab === "proposals" && (
          <div className="space-y-5">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
              <h2 className="text-lg font-bold text-white">
                6 Смелых Архитектурных Решений для{" "}
                <code className="text-indigo-300">contextual-chatbot</code>
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                Как объединить скорость и дешевизну{" "}
                <code>System One (jev.js / council.js)</code> с глубоким
                ассоциативным мышлением, неожиданными аналогиями и ощущением, что
                бот «чувствует» всю жизнь человека.
              </p>
            </div>

            <div className="space-y-4">
              {proposals.map((prop) => {
                const isOpen = openBlueprintId === prop.id;
                return (
                  <div
                    key={prop.id}
                    className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5"
                  >
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 mb-3">
                      <div className="flex items-start gap-3">
                        <span className="px-3 py-1.5 rounded-xl bg-indigo-600/20 border border-indigo-500/40 text-indigo-300 font-mono font-bold text-sm">
                          {prop.number}
                        </span>
                        <div>
                          <h3 className="text-base font-bold text-white">
                            {prop.title}
                          </h3>
                          <p className="text-xs text-slate-400 mt-0.5">
                            {prop.subtitle}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="px-2.5 py-1 rounded-lg bg-emerald-950/60 border border-emerald-500/30 text-emerald-300">
                          {prop.costImpact}
                        </span>
                        <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-indigo-300 font-mono">
                          {prop.jevSlotsUsed}
                        </span>
                      </div>
                    </div>

                    <p className="text-sm text-slate-200 leading-relaxed mb-4">
                      {prop.conceptExplanation}
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800">
                        <div className="text-xs font-semibold text-indigo-300 mb-2">
                          Механика работы по шагам:
                        </div>
                        <ul className="space-y-1.5 text-xs text-slate-300">
                          {prop.howItWorksSteps.map((step, i) => (
                            <li key={i} className="flex items-start gap-2">
                              <span className="text-indigo-400 font-bold">
                                {i + 1}.
                              </span>
                              <span>{step}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
                        <div>
                          <div className="text-xs font-semibold text-amber-300 mb-1">
                            Какую проблему решает:
                          </div>
                          <p className="text-xs text-slate-300 mb-3">
                            {prop.problemSolved}
                          </p>
                        </div>
                        <div>
                          <div className="text-xs font-semibold text-emerald-300 mb-1">
                            Архитектурный баланс и страховка от перегибов:
                          </div>
                          <p className="text-xs text-slate-300">
                            {prop.tradeoffs}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                      <span className="text-xs text-emerald-300 font-medium">
                        {prop.impactScore}
                      </span>
                      <button
                        onClick={() =>
                          setOpenBlueprintId(isOpen ? null : prop.id)
                        }
                        className="inline-flex items-center gap-1.5 text-xs font-medium text-indigo-300 hover:text-indigo-200"
                      >
                        <Code2 className="w-4 h-4" />
                        <span>
                          {isOpen
                            ? "Скрыть ориентировочный чертёж"
                            : `Показать чертёж для ${prop.referenceBlueprint.file}`}
                        </span>
                      </button>
                    </div>

                    {isOpen && (
                      <div className="mt-3">
                        <pre className="text-xs font-mono bg-slate-950 border border-slate-800 rounded-xl p-4 text-indigo-100 overflow-x-auto">
                          {prop.referenceBlueprint.snippet}
                        </pre>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ==================== TAB 4: CLOUDS & SYNAPTIC BRIDGES ==================== */}
        {activeTab === "clouds" && (
          <div className="space-y-5">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
              <h2 className="text-lg font-bold text-white">
                Двухслойная карта памяти: Ядро Личности + Тематические Облака +
                Синаптические Мосты Сна
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                Так выглядит память, когда фоновая стадия{" "}
                <code className="text-indigo-300">
                  runCloudConsolidation()
                </code>{" "}
                в <code>analytics.js</code> не просто раскладывает факты по
                изолированным коробкам, а заранее строит ассоциативные мосты
                между далёкими сферами жизни.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {clouds.map((cloud) => (
                <div
                  key={cloud.slug}
                  className={`rounded-2xl p-5 border ${
                    cloud.domainType === "core_identity"
                      ? "bg-indigo-950/30 border-indigo-500/50 md:col-span-2"
                      : "bg-slate-900/80 border-slate-800"
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <Cloud className="w-4 h-4 text-indigo-400" />
                      <h3 className="text-base font-bold text-white">
                        {cloud.name}
                      </h3>
                    </div>
                    <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-slate-950 border border-slate-800 text-slate-300">
                      {cloud.domainType === "core_identity"
                        ? "ALWAYS-ON БАЗОВЫЙ СЛОЙ"
                        : cloud.domainType === "hobby_resource"
                        ? "РЕСУРСНОЕ / ЛАТЕРАЛЬНОЕ ОБЛАКО"
                        : "ТЕМАТИЧЕСКОЕ ОБЛАКО"}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 mb-3">{cloud.summary}</p>

                  <div className="space-y-2 text-xs">
                    {cloud.memoryData.facts.length > 0 && (
                      <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
                        <div className="font-semibold text-slate-300 mb-1">
                          Факты ({cloud.memoryData.facts.length}):
                        </div>
                        <ul className="space-y-1 text-slate-400">
                          {cloud.memoryData.facts.map((f, i) => (
                            <li key={i}>• {f}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {cloud.memoryData.traits.length > 0 && (
                      <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
                        <div className="font-semibold text-indigo-300 mb-1">
                          Черты характера ({cloud.memoryData.traits.length}):
                        </div>
                        <ul className="space-y-1 text-slate-300">
                          {cloud.memoryData.traits.map((t, i) => (
                            <li key={i}>• {t}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {cloud.memoryData.hypotheses.length > 0 && (
                      <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
                        <div className="font-semibold text-amber-300 mb-1">
                          Гипотезы ({cloud.memoryData.hypotheses.length}):
                        </div>
                        <ul className="space-y-1 text-slate-300">
                          {cloud.memoryData.hypotheses.map((h, i) => (
                            <li key={i}>• {h}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {cloud.synapticBridges.length > 0 && (
                      <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30">
                        <div className="font-semibold text-emerald-300 mb-1.5 flex items-center gap-1.5">
                          <Network className="w-3.5 h-3.5" />
                          <span>
                            Синаптические мосты (создаются в фоновой стадии
                            «Сна»):
                          </span>
                        </div>
                        <div className="space-y-2">
                          {cloud.synapticBridges.map((b, i) => (
                            <div
                              key={i}
                              className="text-emerald-100/90 bg-slate-950/60 p-2.5 rounded-lg border border-emerald-500/20"
                            >
                              <div className="font-semibold text-emerald-300">
                                ↔ Мост в облако «{b.targetCloudName}» (сила{" "}
                                {b.strength}):
                              </div>
                              <div className="text-slate-300 mt-0.5">
                                Паттерн: {b.sharedPattern}
                              </div>
                              <div className="text-emerald-200 mt-1 italic">
                                Подсказка для метафоры: «{b.metaphorHint}»
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
