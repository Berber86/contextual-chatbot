import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "JEV Memory Architecture Lab — Berber86/contextual-chatbot",
  description:
    "Архитектурный разбор, сравнение Legacy vs Current JEV (System One) и интерактивный симулятор ассоциативной памяти для contextual-chatbot.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body className="bg-slate-950 text-slate-100 antialiased selection:bg-indigo-500/30 selection:text-indigo-200">
        {children}
      </body>
    </html>
  );
}
